#!/bin/sh

autoreconf --install
