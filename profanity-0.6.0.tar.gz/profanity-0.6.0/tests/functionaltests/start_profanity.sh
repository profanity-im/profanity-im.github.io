export COLUMNS=300
./profanity -l DEBUG
