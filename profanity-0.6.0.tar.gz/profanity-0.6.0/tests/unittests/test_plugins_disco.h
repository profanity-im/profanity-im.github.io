void returns_empty_list_when_none(void **state);
void returns_added_feature(void **state);
void resets_features_on_close(void **state);
void returns_all_added_features(void **state);
void does_not_add_duplicate_feature(void **state);
void removes_plugin_features(void **state);
void does_not_remove_feature_when_more_than_one_reference(void **state);
