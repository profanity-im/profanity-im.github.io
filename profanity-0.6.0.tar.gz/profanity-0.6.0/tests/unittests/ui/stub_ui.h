void expect_cons_show(char *expected);
void expect_any_cons_show(void);
void expect_cons_show_error(char *expected);
void expect_any_cons_show_error(void);
void expect_win_println(char *message);
