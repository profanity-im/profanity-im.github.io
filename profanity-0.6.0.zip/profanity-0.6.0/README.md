Profanity [![Build Status](https://travis-ci.org/boothj5/profanity.png?branch=master)](https://travis-ci.org/boothj5/profanity)
=========

Profanity is a console based XMPP client inspired by [Irssi](http://www.irssi.org/),

![alt tag](http://www.profanity.im/images/prof-1.png)

See the [User Guide](http://www.profanity.im/userguide.html) for information on installing and using Profanity.

Links
-----

Homepage: http://www.profanity.im

Mailing List: https://groups.google.com/forum/#!forum/profanitydev

Plugins repository: https://github.com/boothj5/profanity-plugins
