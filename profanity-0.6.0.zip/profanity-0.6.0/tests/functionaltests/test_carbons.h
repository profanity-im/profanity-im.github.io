void send_enable_carbons(void **state);
void connect_with_carbons_enabled(void **state);
void send_disable_carbons(void **state);
void receive_carbon(void **state);
void receive_self_carbon(void **state);
void receive_private_carbon(void **state);

