void disconnect_ends_session(void **state);
