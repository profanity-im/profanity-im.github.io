void message_send(void **state);
void message_receive_console(void **state);
void message_receive_chatwin(void **state);
