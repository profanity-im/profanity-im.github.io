void does_not_send_receipt_request_to_barejid(void **state);
void send_receipt_request(void **state);
void send_receipt_on_request(void **state);

