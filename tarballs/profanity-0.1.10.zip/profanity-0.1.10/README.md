Profanity
=========

Profanity is a console based jabber client inspired by [Irssi](http://www.irssi.org/),

See the [project wiki](https://github.com/boothj5/profanity/wiki) for information on installing, upgrading and using Profanity.

Links
-----

Homepage: http://www.profanity.im

Mailing List: https://groups.google.com/forum/#!forum/profanitydev