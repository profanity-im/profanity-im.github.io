void message_send(void **state);
void message_receive(void **state);
