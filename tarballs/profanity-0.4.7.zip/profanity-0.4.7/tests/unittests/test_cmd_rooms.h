void cmd_rooms_shows_message_when_disconnected(void **state);
void cmd_rooms_shows_message_when_disconnecting(void **state);
void cmd_rooms_shows_message_when_connecting(void **state);
void cmd_rooms_shows_message_when_started(void **state);
void cmd_rooms_shows_message_when_undefined(void **state);
void cmd_rooms_uses_account_default_when_no_arg(void **state);
void cmd_rooms_arg_used_when_passed(void **state);
