void sends_new_item(void **state);
void sends_new_item_nick(void **state);
void sends_remove_item(void **state);
void sends_nick_change(void **state);
