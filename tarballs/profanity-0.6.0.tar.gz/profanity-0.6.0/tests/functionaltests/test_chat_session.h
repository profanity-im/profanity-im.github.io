void sends_message_to_barejid_when_contact_offline(void **state);
void sends_message_to_barejid_when_contact_online(void **state);
void sends_message_to_fulljid_when_received_from_fulljid(void **state);
void sends_subsequent_messages_to_fulljid(void **state);
void resets_to_barejid_after_presence_received(void **state);
void new_session_when_message_received_from_different_fulljid(void **state);

