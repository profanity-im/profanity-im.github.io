void ping_server(void **state);
void ping_server_not_supported(void **state);
void ping_responds_to_server_request(void **state);
void ping_jid(void **state);
void ping_jid_not_supported(void **state);
