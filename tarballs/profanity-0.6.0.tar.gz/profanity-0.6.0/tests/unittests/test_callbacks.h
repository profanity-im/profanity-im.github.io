void returns_no_commands(void **state);
void returns_commands(void **state);
