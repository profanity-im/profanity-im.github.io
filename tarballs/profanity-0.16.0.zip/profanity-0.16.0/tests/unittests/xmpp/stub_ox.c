#include <stdio.h>
#include <glib.h>
#include <stdlib.h>

gboolean
ox_announce_public_key(const char* const filename)
{
    return FALSE;
}

void
ox_discover_public_key(const char* const jid)
{
}

void
ox_request_public_key(const char* const jid, const char* const fingerprint)
{
}
