#ifndef TOOLS_PLUGIN_DOWNLOAD_H
#define TOOLS_PLUGIN_DOWNLOAD_H

#include <stdlib.h>
typedef struct prof_win_t ProfWin;
typedef struct http_download_t HTTPDownload;

void*
plugin_download_install(void* userdata)
{
    return NULL;
}

void
plugin_download_add_download(HTTPDownload* download)
{
}

#endif
