#ifndef TESTSUITE_H
#define TESTSUITE_H

void register_history_tests(void);
void register_roster_tests(void);
void register_common_tests(void);
void register_autocomplete_tests(void);
void register_parser_tests(void);
void register_jid_tests(void);

#endif
