#include <stdlib.h>
#include <glib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include "prof_cmocka.h"
#include "command/cmd_ac.h"
#include "command/test_cmd_ac.h"
#include "xmpp/xmpp.h"

static void
_create_test_file(const char* path)
{
    FILE* f = fopen(path, "w");
    if (f) {
        fprintf(f, "test");
        fclose(f);
    }
}

void
cmd_ac_complete_filepath__segfaults_when_empty(void** state)
{
    gchar* result = cmd_ac_complete_filepath("/sendfile ", "/sendfile", FALSE);

    g_free(result);
}

void
cmd_ac_complete_filepath__finds_files_in_current_dir(void** state)
{
    mkdir("test_dir", 0755);
    _create_test_file("test_dir/file1.txt");
    _create_test_file("test_dir/file2.txt");

    gchar* result = cmd_ac_complete_filepath("/sendfile test_dir/file", "/sendfile", FALSE);
    assert_non_null(result);
    assert_string_equal(result, "/sendfile test_dir/file1.txt");
    g_free(result);

    remove("test_dir/file1.txt");
    remove("test_dir/file2.txt");
    rmdir("test_dir");
}

void
cmd_ac_complete_filepath__finds_files_with_dot_slash(void** state)
{
    mkdir("test_dir", 0755);
    _create_test_file("test_dir/file1.txt");

    gchar* result = cmd_ac_complete_filepath("/sendfile ./test_dir/file", "/sendfile", FALSE);
    assert_non_null(result);
    assert_string_equal(result, "/sendfile ./test_dir/file1.txt");
    g_free(result);

    remove("test_dir/file1.txt");
    rmdir("test_dir");
}

void
cmd_ac_complete_filepath__cycles_through_files(void** state)
{
    mkdir("test_dir", 0755);
    _create_test_file("test_dir/file1.txt");
    _create_test_file("test_dir/file2.txt");

    // 1st TAB
    gchar* res1 = cmd_ac_complete_filepath("/sendfile test_dir/file", "/sendfile", FALSE);
    assert_non_null(res1);
    assert_string_equal(res1, "/sendfile test_dir/file1.txt");

    // 2nd TAB
    gchar* res2 = cmd_ac_complete_filepath(res1, "/sendfile", FALSE);
    assert_non_null(res2);
    assert_string_equal(res2, "/sendfile test_dir/file2.txt");

    // 3rd TAB
    gchar* res3 = cmd_ac_complete_filepath(res2, "/sendfile", FALSE);
    assert_non_null(res3);
    assert_string_equal(res3, "/sendfile test_dir/file1.txt");

    // SHIFT-TAB
    gchar* res4 = cmd_ac_complete_filepath(res3, "/sendfile", TRUE);
    assert_non_null(res4);
    assert_string_equal(res4, "/sendfile test_dir/file2.txt");

    g_free(res1);
    g_free(res2);
    g_free(res3);
    g_free(res4);

    remove("test_dir/file1.txt");
    remove("test_dir/file2.txt");
    rmdir("test_dir");
}

void
cmd_ac_complete__returns_null_for_parameterless_command(void** state)
{
    ProfWin window;
    window.type = WIN_CONSOLE;

    gchar* res1 = cmd_ac_complete(&window, "/correct-e", FALSE);
    assert_non_null(res1);
    assert_string_equal(res1, "/correct-editor");
    g_free(res1);

    will_return(connection_get_status, JABBER_DISCONNECTED);
    gchar* res2 = cmd_ac_complete(&window, "/correct-editor ", FALSE);
    assert_null(res2);
}
