#include "prof_cmocka.h"
#include <stdlib.h>

#include "xmpp/muc.h"
#include "xmpp/test_muc.h"

void prof_shutdown(void);

int
muc_before_test(void** state)
{
    muc_init();
    return 0;
}

int
muc_after_test(void** state)
{
    prof_shutdown();
    return 0;
}

void
muc_invites_add__updates__invites_list(void** state)
{
    const gchar* room = "room@conf.server";
    muc_invites_add(room, NULL);

    gboolean invite_exists = muc_invites_contain(room);

    assert_true(invite_exists);
}

void
muc_invites_remove__updates__invites_list(void** state)
{
    const gchar* room = "room@conf.server";
    muc_invites_add(room, NULL);
    muc_invites_remove(room);

    gboolean invite_exists = muc_invites_contain(room);

    assert_false(invite_exists);
}

void
muc_invites_count__returns__0_when_no_invites(void** state)
{
    int invite_count = muc_invites_count();

    assert_true(invite_count == 0);
}

void
muc_invites_count__returns__5_when_five_invites_added(void** state)
{
    muc_invites_add("room1@conf.server", NULL);
    muc_invites_add("room2@conf.server", NULL);
    muc_invites_add("room3@conf.server", NULL);
    muc_invites_add("room4@conf.server", NULL);
    muc_invites_add("room5@conf.server", NULL);

    int invite_count = muc_invites_count();

    assert_true(invite_count == 5);
}

void
muc_active__is__false_when_not_joined(void** state)
{
    const gchar* room = "room@server.org";

    gboolean room_is_active = muc_active(room);

    assert_false(room_is_active);
}

void
muc_active__is__true_when_joined(void** state)
{
    const gchar* room = "room@server.org";
    const gchar* nick = "bob";
    muc_join(room, nick, NULL, FALSE);

    gboolean room_is_active = muc_active(room);

    assert_true(room_is_active);
}

void
muc_join__rejects_invalid_room_jid(void** state)
{
    const gchar* room = "room@@server.org";
    const gchar* nick = "bob";
    muc_join(room, nick, NULL, FALSE);

    assert_false(muc_active(room));
    GList* rooms = muc_rooms();
    assert_null(rooms);
}

void
muc_join__rejects_null_room(void** state)
{
    muc_join(NULL, "bob", NULL, FALSE);

    GList* rooms = muc_rooms();
    assert_null(rooms);
}

void
muc_join__rejects_room_without_service(void** state)
{
    const gchar* room = "room";
    muc_join(room, "bob", NULL, FALSE);

    assert_false(muc_active(room));
    GList* rooms = muc_rooms();
    assert_null(rooms);
}

void
muc_join__rejects_full_jid(void** state)
{
    const gchar* room = "room@server.org/bob";
    muc_join(room, "bob", NULL, FALSE);

    assert_false(muc_active(room));
    GList* rooms = muc_rooms();
    assert_null(rooms);
}

void
muc_roster_add__returns_false_when_room_or_nick_null(void** state)
{
    gboolean res1 = muc_roster_add(NULL, "bob", NULL, NULL, NULL, NULL, NULL);
    assert_false(res1);

    gboolean res2 = muc_roster_add("room@server.org", NULL, NULL, NULL, NULL, NULL, NULL);
    assert_false(res2);
}

void
muc_roster_add__adds_occupant_to_room_roster(void** state)
{
    const gchar* room = "room@server.org";
    const gchar* nick = "bob";
    muc_join(room, nick, NULL, FALSE);

    gboolean added = muc_roster_add(room, "alice", NULL, "participant", "member", "chat", "online");
    assert_true(added);
    assert_true(muc_roster_contains_nick(room, "alice"));
}

void
muc_supports_mam__is__false_when_not_joined(void** state)
{
    gboolean supported = muc_supports_mam("unjoined@server.org");
    assert_false(supported);
}

void
muc_supports_mam__is__true_when_feature_advertised(void** state)
{
    const gchar* room = "room@server.org";
    const gchar* nick = "bob";
    muc_join(room, nick, NULL, FALSE);

    GSList* features = NULL;
    features = g_slist_append(features, "http://jabber.org/protocol/muc");
    features = g_slist_append(features, "urn:xmpp:mam:2");

    muc_set_features(room, features);

    gboolean supported = muc_supports_mam(room);
    assert_true(supported);

    g_slist_free(features);
}

void
muc_supports_mam__is__false_when_feature_not_advertised(void** state)
{
    const gchar* room = "room@server.org";
    const gchar* nick = "bob";
    muc_join(room, nick, NULL, FALSE);

    GSList* features = NULL;
    features = g_slist_append(features, "http://jabber.org/protocol/muc");

    muc_set_features(room, features);

    gboolean supported = muc_supports_mam(room);
    assert_false(supported);

    g_slist_free(features);
}
