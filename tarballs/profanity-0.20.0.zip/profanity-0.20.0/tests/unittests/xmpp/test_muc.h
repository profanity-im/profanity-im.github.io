#ifndef TESTS_TEST_MUC_H
#define TESTS_TEST_MUC_H

int muc_before_test(void** state);
int muc_after_test(void** state);

void muc_invites_add__updates__invites_list(void** state);
void muc_invites_remove__updates__invites_list(void** state);
void muc_invites_count__returns__0_when_no_invites(void** state);
void muc_invites_count__returns__5_when_five_invites_added(void** state);
void muc_active__is__false_when_not_joined(void** state);
void muc_active__is__true_when_joined(void** state);
void muc_join__rejects_invalid_room_jid(void** state);
void muc_join__rejects_null_room(void** state);
void muc_join__rejects_room_without_service(void** state);
void muc_join__rejects_full_jid(void** state);
void muc_roster_add__returns_false_when_room_or_nick_null(void** state);
void muc_roster_add__adds_occupant_to_room_roster(void** state);
void muc_supports_mam__is__false_when_not_joined(void** state);
void muc_supports_mam__is__true_when_feature_advertised(void** state);
void muc_supports_mam__is__false_when_feature_not_advertised(void** state);

#endif
