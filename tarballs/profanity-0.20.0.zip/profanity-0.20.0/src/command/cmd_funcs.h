/*
 * cmd_funcs.h
 * vim: expandtab:ts=4:sts=4:sw=4
 *
 * Copyright (C) 2012 - 2019 James Booth <boothj5@gmail.com>
 * Copyright (C) 2019 - 2026 Michael Vetter <jubalh@iodoru.org>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later WITH OpenSSL-exception
 */

#ifndef COMMAND_CMD_FUNCS_H
#define COMMAND_CMD_FUNCS_H

#include "ui/win_types.h"

// Command help strings
typedef struct cmd_help_t
{
    gchar* tags[20];
    gchar* synopsis[50];
    gchar* desc;
    gchar* args[128][2];
    gchar* examples[20];
} CommandHelp;

/*
 * Command structure
 *
 * cmd - The command string including leading '/'
 * parser - The function used to parse arguments
 * min_args - Minimum number of arguments
 * max_args - Maximum number of arguments, -1 for infinite
 * setting_func - Function to display current settings to the console
 * sub_funcs - Optional list of functions mapped to the first argument
 * func - Main function to call when no arguments, or sub_funcs not implemented
 * help - A help struct containing usage info etc
 */
typedef struct cmd_t
{
    gchar* cmd;
    gchar** (*parser)(const gchar* const inp, int min, int max, gboolean* result);
    int min_args;
    int max_args;
    void (*setting_func)(void);
    struct
    {
        const gchar* cmd;
        gboolean (*func)(ProfWin* window, const gchar* const command, gchar** args);
    } sub_funcs[50];
    gboolean (*func)(ProfWin* window, const gchar* const command, gchar** args);
    CommandHelp help;
} Command;

gboolean cmd_process_input(ProfWin* window, char* inp);
void cmd_execute_connect(ProfWin* window, const gchar* const account);

gboolean cmd_about(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_autoaway(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_autoconnect(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_autoping(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_mucping(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_beep(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_caps(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_logging(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_clear(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_close(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_connect(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_disco(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_sendfile(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_lastactivity(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_disconnect(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_flash(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_tray(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_gone(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_group(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_help(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_history(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_carbons(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_receipts(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_info(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_intype(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_invite(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_join(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_log(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_msg(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_nick(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_notify(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_pgp(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_privacy(ProfWin* window, const gchar* const command, gchar** args);
#ifdef HAVE_LIBGPGME
gboolean cmd_ox(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_ox_log(ProfWin* window, const gchar* const command, gchar** args);
#endif // HAVE_LIBGPGME
gboolean cmd_outtype(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_prefs(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_priority(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_quit(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_reconnect(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_room(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_rooms(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_bookmark(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_bookmark_ignore(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_roster(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_software(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_splash(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_spellcheck(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_states(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_status_get(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_status_set(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_sub(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_theme(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_wintitle(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_vercheck(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_who(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_win(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_alias(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_xmlconsole(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_ping(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_form(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_occupants(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_kick(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_ban(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_subject(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_affiliation(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_role(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_privileges(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_presence(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_wrap(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_time(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_resource(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_inpblock(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_titlebar(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_titlebar_show_hide(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_mainwin(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_statusbar(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_inputwin(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_export(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_charset(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_console(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_command_list(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_command_exec(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_change_password(ProfWin* window, const gchar* const command, gchar** args);

gboolean cmd_plugins(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_plugins_install(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_plugins_uninstall(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_plugins_load(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_plugins_unload(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_plugins_enable(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_plugins_disable(ProfWin* window, const gchar* const command, gchar** args);

gboolean cmd_blocked(ProfWin* window, const gchar* const command, gchar** args);

gboolean cmd_account(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_account_list(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_account_show(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_account_add(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_account_remove(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_account_enable(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_account_disable(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_account_rename(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_account_default(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_account_set(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_account_clear(ProfWin* window, const gchar* const command, gchar** args);

gboolean cmd_tls_certpath(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_tls_trust(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_tls_trusted(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_tls_revoke(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_tls_cert(ProfWin* window, const gchar* const command, gchar** args);

gboolean cmd_otr_char(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_log(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_libver(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_policy(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_gen(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_myfp(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_theirfp(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_start(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_end(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_trust(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_untrust(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_secret(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_question(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_answer(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_otr_sendfile(ProfWin* window, const gchar* const command, gchar** args);

gboolean cmd_wins(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_wins_unread(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_wins_attention(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_wins_prune(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_wins_swap(ProfWin* window, const gchar* const command, gchar** args);

gboolean cmd_form_field(ProfWin* window, char* tag, gchar** args);

gboolean cmd_omemo_gen(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_omemo_char(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_omemo_log(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_omemo_start(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_omemo_end(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_omemo_fingerprint(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_omemo_trust(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_omemo_untrust(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_omemo_trust_mode(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_omemo_policy(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_omemo_clear_device_list(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_omemo_qrcode(ProfWin* window, const gchar* const command, gchar** args);

gboolean cmd_changes(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_save(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_reload(ProfWin* window, const gchar* const command, gchar** args);

gboolean cmd_color(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_avatar(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_os(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_correction(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_correct(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_slashguard(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_serversoftware(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_url_open(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_url_save(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_executable_avatar(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_executable_urlopen(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_executable_urlsave(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_executable_editor(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_executable_vcard_photo(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_editor(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_correct_editor(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_redraw(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_silence(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_register(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_mood(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_strophe(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_stamp(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_vcard(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_vcard_edit(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_vcard_get(ProfWin* window, const gchar* const command, gchar** args);
gboolean cmd_vcard_photo(ProfWin* window, const gchar* const command, gchar** args);

#endif
