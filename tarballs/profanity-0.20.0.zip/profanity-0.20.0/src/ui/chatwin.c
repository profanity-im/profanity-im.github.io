/*
 * chatwin.c
 * vim: expandtab:ts=4:sts=4:sw=4
 *
 * Copyright (C) 2012 - 2019 James Booth <boothj5@gmail.com>
 * Copyright (C) 2019 - 2026 Michael Vetter <jubalh@iodoru.org>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later WITH OpenSSL-exception
 */

#include "config.h"

#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "common.h"
#include "xmpp/chat_session.h"
#include "window_list.h"
#include "xmpp/roster_list.h"
#include "log.h"
#include "database.h"
#include "config/preferences.h"
#include "ui/ui.h"
#include "ui/window.h"
#include "ui/titlebar.h"
#include "plugins/plugins.h"
#ifdef HAVE_LIBOTR
#include "otr/otr.h"
#endif
#ifdef HAVE_LIBGPGME
#include "pgp/gpg.h"
#endif
#ifdef HAVE_OMEMO
#include "omemo/omemo.h"
#endif

static void _chatwin_history(ProfChatWin* chatwin, const char* const contact_barejid);
static void _chatwin_set_last_message(ProfChatWin* chatwin, const char* const id, const char* const message);

#ifdef HAVE_LIBGPGME
static gboolean
_pgp_automatic_start(const char* const recipient)
{
    gboolean result = FALSE;
    ProfAccount* account = accounts_get_account(session_get_account_name());

    if (g_list_find_custom(account->pgp_enabled, recipient, (GCompareFunc)g_strcmp0)) {
        result = TRUE;
    }

    account_free(account);
    return result;
}

static gboolean
_ox_automatic_start(const char* const recipient)
{
    gboolean result = FALSE;
    ProfAccount* account = accounts_get_account(session_get_account_name());

    if (g_list_find_custom(account->ox_enabled, recipient, (GCompareFunc)g_strcmp0)) {
        result = TRUE;
    }

    account_free(account);
    return result;
}
#endif

ProfChatWin*
chatwin_new(const char* const barejid)
{
    ProfWin* window = wins_new_chat(barejid);
    ProfChatWin* chatwin = (ProfChatWin*)window;

    if (prefs_get_boolean(PREF_CHLOG) && prefs_get_boolean(PREF_HISTORY)) {
        _chatwin_history(chatwin, barejid);
    }

    if (prefs_get_boolean(PREF_MAM) && connection_supports(XMPP_FEATURE_MAM2)) {
        win_print_loading_history(window);
        iq_mam_request(window, NULL);
    }

    // if the contact is offline, show a message
    PContact contact = roster_get_contact(barejid);
    if (contact) {
        if (strcmp(p_contact_presence(contact), "offline") == 0) {
            const char* const show = p_contact_presence(contact);
            const char* const status = p_contact_status(contact);
            win_show_status_string(window, barejid, show, status, NULL, "--", "offline");
        }
    }

    // We start a new OMEMO session if this contact has been configured accordingly.
    // However, if OTR is *also* configured, ask the user to choose between OMEMO and OTR.

    gboolean is_pgp_secure = FALSE;
    gboolean is_ox_secure = FALSE;
    gboolean is_otr_secure = FALSE;
    gboolean is_omemo_secure = FALSE;
#ifdef HAVE_LIBGPGME
    is_pgp_secure = _pgp_automatic_start(barejid);
    is_ox_secure = _ox_automatic_start(barejid);
#endif

#ifdef HAVE_OMEMO
    is_omemo_secure = omemo_automatic_start(barejid);
#endif

#ifdef HAVE_LIBOTR
    is_otr_secure = otr_is_secure(barejid);
#endif

    if (is_omemo_secure + is_otr_secure + is_pgp_secure + is_ox_secure > 1) {
        win_println(window, THEME_DEFAULT, "!", "This chat could be either OMEMO, PGP, OX or OTR encrypted, but not more than one. "
                                                "Use '/omemo start', '/pgp start', '/ox start' or '/otr start' to select the encryption method.");
    } else if (is_omemo_secure) {
#ifdef HAVE_OMEMO
        // Start the OMEMO session
        omemo_start_session(barejid);
        chatwin->is_omemo = TRUE;
#endif
    } else if (is_pgp_secure) {
        // Start the PGP session
        chatwin->pgp_send = TRUE;
    } else if (is_ox_secure) {
        // Start the OX session
        chatwin->is_ox = TRUE;
    }

    return chatwin;
}

void
chatwin_receipt_received(ProfChatWin* chatwin, const char* const id)
{
    assert(chatwin != NULL);

    ProfWin* win = (ProfWin*)chatwin;
    win_mark_received(win, id);
}

#ifdef HAVE_LIBOTR
void
chatwin_otr_secured(ProfChatWin* chatwin, gboolean trusted)
{
    assert(chatwin != NULL);

    chatwin->is_otr = TRUE;
    chatwin->otr_is_trusted = trusted;

    ProfWin* window = (ProfWin*)chatwin;
    if (trusted) {
        win_println(window, THEME_OTR_STARTED_TRUSTED, "!", "OTR session started (trusted).");
    } else {
        win_println(window, THEME_OTR_STARTED_UNTRUSTED, "!", "OTR session started (untrusted).");
    }

    if (wins_is_current(window)) {
        title_bar_switch();
    } else {
        int num = wins_get_num(window);
        status_bar_new(num, WIN_CHAT, chatwin->barejid);

        int ui_index = num;
        if (ui_index == 10) {
            ui_index = 0;
        }
        cons_show("%s started an OTR session (%d).", chatwin->barejid, ui_index);
        cons_alert(window);
    }
}

void
chatwin_otr_unsecured(ProfChatWin* chatwin, gboolean disable_otr)
{
    assert(chatwin != NULL);

    if (disable_otr) {
        chatwin->is_otr = FALSE;
    }
    chatwin->otr_is_trusted = FALSE;

    ProfWin* window = (ProfWin*)chatwin;
    win_println(window, THEME_OTR_ENDED, "!", "OTR session ended.");
    if (wins_is_current(window)) {
        title_bar_switch();
    }
}

void
chatwin_otr_smp_event(ProfChatWin* chatwin, prof_otr_smp_event_t event, void* data)
{
    assert(chatwin != NULL);

    switch (event) {
    case PROF_OTR_SMP_INIT:
        win_println((ProfWin*)chatwin, THEME_DEFAULT, "!",
                    "%s wants to authenticate your identity, use '/otr secret <secret>'.", chatwin->barejid);
        break;
    case PROF_OTR_SMP_INIT_Q:
        win_println((ProfWin*)chatwin, THEME_DEFAULT, "!",
                    "%s wants to authenticate your identity with the following question:", chatwin->barejid);
        win_println((ProfWin*)chatwin, THEME_DEFAULT, "!", "  %s", (char*)data);
        win_println((ProfWin*)chatwin, THEME_DEFAULT, "!", "use '/otr answer <answer>'.");
        break;
    case PROF_OTR_SMP_SENDER_FAIL:
        win_println((ProfWin*)chatwin, THEME_DEFAULT, "!",
                    "Authentication failed, the secret you entered does not match the secret entered by %s.",
                    chatwin->barejid);
        break;
    case PROF_OTR_SMP_RECEIVER_FAIL:
        win_println((ProfWin*)chatwin, THEME_DEFAULT, "!",
                    "Authentication failed, the secret entered by %s does not match yours.", chatwin->barejid);
        break;
    case PROF_OTR_SMP_ABORT:
        win_println((ProfWin*)chatwin, THEME_DEFAULT, "!", "SMP session aborted.");
        break;
    case PROF_OTR_SMP_SUCCESS:
        win_println((ProfWin*)chatwin, THEME_DEFAULT, "!", "Authentication successful.");
        break;
    case PROF_OTR_SMP_SUCCESS_Q:
        win_println((ProfWin*)chatwin, THEME_DEFAULT, "!", "%s successfully authenticated you.", chatwin->barejid);
        break;
    case PROF_OTR_SMP_FAIL_Q:
        win_println((ProfWin*)chatwin, THEME_DEFAULT, "!", "%s failed to authenticate you.", chatwin->barejid);
        break;
    case PROF_OTR_SMP_AUTH:
        win_println((ProfWin*)chatwin, THEME_DEFAULT, "!", "Authenticating %s…", chatwin->barejid);
        break;
    case PROF_OTR_SMP_AUTH_WAIT:
        win_println((ProfWin*)chatwin, THEME_DEFAULT, "!", "Awaiting authentication from %s…", chatwin->barejid);
        break;
    default:
        break;
    }
}

void
chatwin_otr_trust(ProfChatWin* chatwin)
{
    assert(chatwin != NULL);

    chatwin->is_otr = TRUE;
    chatwin->otr_is_trusted = TRUE;

    ProfWin* window = (ProfWin*)chatwin;
    win_println(window, THEME_OTR_TRUSTED, "!", "OTR session trusted.");
    if (wins_is_current(window)) {
        title_bar_switch();
    }
}

void
chatwin_otr_untrust(ProfChatWin* chatwin)
{
    assert(chatwin != NULL);

    chatwin->is_otr = TRUE;
    chatwin->otr_is_trusted = FALSE;

    ProfWin* window = (ProfWin*)chatwin;
    win_println(window, THEME_OTR_UNTRUSTED, "!", "OTR session untrusted.");
    if (wins_is_current(window)) {
        title_bar_switch();
    }
}
#endif

void
chatwin_recipient_gone(ProfChatWin* chatwin)
{
    assert(chatwin != NULL);

    win_println((ProfWin*)chatwin, THEME_GONE, "!", "<- %s has left the conversation.", roster_get_display_name(chatwin->barejid));
}

void
chatwin_incoming_msg(ProfChatWin* chatwin, ProfMessage* message, gboolean win_created)
{
    assert(chatwin != NULL);

    if (message->plain == NULL) {
        log_error("chatwin_incoming_msg: Message with no plain field from: %s", message->from_jid);
        return;
    }

    char* old_plain = message->plain;
    auto_gchar gchar* new_plain = plugins_pre_chat_message_display(message->from_jid->barejid, message->from_jid->resourcepart, message->plain);
    if (new_plain)
        message->plain = new_plain;

    gboolean show_message = TRUE;

    ProfWin* window = (ProfWin*)chatwin;
    int num = wins_get_num(window);

    auto_gchar gchar* display_name = get_display_name(message, NULL);

#ifdef HAVE_LIBGPGME
    if (prefs_get_boolean(PREF_PGP_PUBKEY_AUTOIMPORT)) {
        if (p_gpg_is_public_key_format(message->plain)) {
            ProfPGPKey* key = p_gpg_import_pubkey(message->plain);
            if (key != NULL) {
                show_message = FALSE;
                win_println(window, THEME_DEFAULT, "-", "Received and imported PGP key %s: \"%s\". To assign it to the correspondent using /pgp setkey %s %s", key->fp, key->name, display_name, key->id);
                p_gpg_free_key(key);
            } else {
                win_println(window, THEME_DEFAULT, "-", "Received PGP key, but couldn't import PGP key above.");
            }
        }
    }
#endif

    gboolean is_current = wins_is_current(window);
    gboolean notify = prefs_do_chat_notify(is_current) && !message->is_mam;

    // currently viewing chat window with sender
    if (wins_is_current(window)) {
        if (show_message) {
            win_print_incoming(window, display_name, message);
        }
        title_bar_set_typing(FALSE);
        status_bar_active(num, WIN_CHAT, chatwin->barejid);

        // not currently viewing chat window with sender
    } else {
        status_bar_new(num, WIN_CHAT, chatwin->barejid);

        if (!message->is_mam) {
            cons_show_incoming_message(display_name, num, chatwin->unread, window);

            if (prefs_get_boolean(PREF_FLASH)) {
                ui_flash();
            }

            chatwin->unread++;
        }

        // TODO: so far we don't ask for MAM when incoming message occurs.
        // Need to figure out:
        // 1) only send IQ once
        // 2) sort incoming messages on timestamp
        // for now if MAM is enabled we dont show no history from sql either

        // MUCPMs also get printed here. In their case we don't save any logs (because nick owners can change) and thus we shouldn't read logs
        // (and if we do we need to check the resourcepart)
        if (prefs_get_boolean(PREF_CHLOG) && prefs_get_boolean(PREF_HISTORY) && message->type == PROF_MSG_TYPE_CHAT) {
            _chatwin_history(chatwin, chatwin->barejid);
        }

        // show users status first, when receiving message via delayed delivery
        if (message->timestamp && win_created) {
            PContact pcontact = roster_get_contact(chatwin->barejid);
            if (pcontact) {
                win_show_contact(window, pcontact);
            }
        }

        win_insert_last_read_position_marker((ProfWin*)chatwin, chatwin->barejid);
        if (show_message) {
            win_print_incoming(window, display_name, message);
        }
    }

    if (!message->is_mam) {
        wins_add_quotes_ac(window, message->plain, FALSE);

        if (prefs_get_boolean(PREF_BEEP)) {
            ui_beep();
        }
    }

    if (notify) {
        notify_message(display_name, message->from_jid->barejid, num, message->plain);
    }

    plugins_post_chat_message_display(message->from_jid->barejid, message->from_jid->resourcepart, message->plain);

    message->plain = old_plain;
}

void
chatwin_outgoing_msg(ProfChatWin* chatwin, const char* const message, const char* id, prof_enc_t enc_mode,
                     gboolean request_receipt, const char* const replace_id)
{
    assert(chatwin != NULL);

    ProfWin* window = (ProfWin*)chatwin;
    wins_add_quotes_ac(window, message, FALSE);

    const gchar* enc_char = get_enc_char(enc_mode, chatwin->outgoing_char);

    const Jid* myjid = connection_get_jid();
    auto_gchar gchar* plugin_message = plugins_pre_chat_message_display(myjid->barejid, myjid->resourcepart, message);
    const char* display_message = plugin_message ?: message;

    if (request_receipt && id) {
        auto_gchar gchar* outgoing_str = prefs_get_string(PREF_OUTGOING_STAMP);
        win_print_outgoing_with_receipt((ProfWin*)chatwin, enc_char, outgoing_str, display_message, id, replace_id);
    } else {
        win_print_outgoing((ProfWin*)chatwin, enc_char, id, replace_id, display_message);
    }

    plugins_post_chat_message_display(myjid->barejid, myjid->resourcepart, display_message);

    // save last id and message for LMC
    if (id) {
        const char* const save_id = replace_id ? replace_id : id;
        _chatwin_set_last_message(chatwin, save_id, display_message);
    }
}

void
chatwin_outgoing_carbon(ProfChatWin* chatwin, ProfMessage* message)
{
    assert(chatwin != NULL);

    const gchar* enc_char = get_show_char(message->enc);

    ProfWin* window = (ProfWin*)chatwin;

    char* old_plain = message->plain;
    auto_gchar gchar* plugin_msg = plugins_pre_chat_message_display(message->from_jid->barejid, message->from_jid->resourcepart, message->plain);
    if (plugin_msg)
        message->plain = plugin_msg;

    win_print_outgoing(window, enc_char, message->id, message->replace_id, message->plain);

    plugins_post_chat_message_display(message->from_jid->barejid, message->from_jid->resourcepart, message->plain);
    message->plain = old_plain;

    int num = wins_get_num(window);
    status_bar_active(num, WIN_CHAT, chatwin->barejid);
}

void
chatwin_contact_online(ProfChatWin* chatwin, Resource* resource, GDateTime* last_activity)
{
    assert(chatwin != NULL);

    const char* show = string_from_resource_presence(resource->presence);
    PContact contact = roster_get_contact(chatwin->barejid);
    auto_gchar gchar* display_str = p_contact_create_display_string(contact, resource->name);

    win_show_status_string((ProfWin*)chatwin, display_str, show, resource->status, last_activity, "++", "online");
}

void
chatwin_contact_offline(ProfChatWin* chatwin, const gchar* const resource, const gchar* const status)
{
    assert(chatwin != NULL);

    PContact contact = roster_get_contact(chatwin->barejid);
    auto_gchar gchar* display_str = p_contact_create_display_string(contact, resource);

    win_show_status_string((ProfWin*)chatwin, display_str, "offline", status, NULL, "--", "offline");
}

gchar*
chatwin_get_string(ProfChatWin* chatwin)
{
    assert(chatwin != NULL);

    GString* res = g_string_new("Chat ");

    jabber_conn_status_t conn_status = connection_get_status();
    if (conn_status == JABBER_CONNECTED) {
        PContact contact = roster_get_contact(chatwin->barejid);
        if (contact == NULL) {
            g_string_append(res, chatwin->barejid);
        } else {
            const char* display_name = p_contact_name_or_jid(contact);
            g_string_append(res, display_name);
            g_string_append_printf(res, " - %s", p_contact_presence(contact));
        }
    } else {
        g_string_append(res, chatwin->barejid);
    }

    if (chatwin->unread > 0) {
        g_string_append_printf(res, ", %d unread", chatwin->unread);
    }

    return g_string_free_and_steal(res);
}

void
chatwin_set_enctext(ProfChatWin* chatwin, const char* const enctext)
{
    g_set_str(&chatwin->enctext, enctext);
}

void
chatwin_unset_enctext(ProfChatWin* chatwin)
{
    g_clear_pointer(&chatwin->enctext, g_free);
}

void
chatwin_set_incoming_char(ProfChatWin* chatwin, const char* const ch)
{
    g_set_str(&chatwin->incoming_char, ch);
}

void
chatwin_unset_incoming_char(ProfChatWin* chatwin)
{
    g_clear_pointer(&chatwin->incoming_char, g_free);
}

void
chatwin_set_outgoing_char(ProfChatWin* chatwin, const char* const ch)
{
    g_set_str(&chatwin->outgoing_char, ch);
}

void
chatwin_unset_outgoing_char(ProfChatWin* chatwin)
{
    g_clear_pointer(&chatwin->outgoing_char, g_free);
}

static void
_chatwin_history(ProfChatWin* chatwin, const char* const contact_barejid)
{
    if (!chatwin->history_shown) {
        GSList* history = log_database_get_previous_chat(contact_barejid, NULL, NULL, FALSE, FALSE);
        GSList* curr = history;

        while (curr) {
            ProfMessage* msg = curr->data;
            char* old_plain = msg->plain;
            auto_gchar gchar* plugin_msg = plugins_pre_chat_message_display(msg->from_jid->barejid, msg->from_jid->resourcepart, msg->plain);
            if (plugin_msg)
                msg->plain = plugin_msg;
            win_print_history((ProfWin*)chatwin, msg);
            plugins_post_chat_message_display(msg->from_jid->barejid, msg->from_jid->resourcepart, msg->plain);
            msg->plain = old_plain;
            curr = g_slist_next(curr);
        }
        chatwin->history_shown = TRUE;

        g_slist_free_full(history, (GDestroyNotify)message_free);
    }
}

// Print history starting from start_time to end_time if end_time is null the
// first entry's timestamp in the buffer is used. Flip true to prepend to buffer.
// Timestamps should be in iso8601
gboolean
chatwin_db_history(ProfChatWin* chatwin, const char* start_time, const char* end_time, gboolean flip)
{
    auto_gchar gchar* end_time_ = NULL;
    if (!end_time && buffer_size(((ProfWin*)chatwin)->layout->buffer) != 0) {
        end_time = end_time_ = g_date_time_format_iso8601(buffer_get_entry(((ProfWin*)chatwin)->layout->buffer, 0)->time);
    }

    GSList* history = log_database_get_previous_chat(chatwin->barejid, start_time, end_time, !flip, flip);
    gboolean has_items = g_slist_length(history) != 0;
    GSList* curr = history;

    while (curr) {
        ProfMessage* msg = curr->data;
        char* old_plain = msg->plain;
        auto_gchar gchar* plugin_msg = plugins_pre_chat_message_display(msg->from_jid->barejid, msg->from_jid->resourcepart, msg->plain);
        if (plugin_msg)
            msg->plain = plugin_msg;
        if (flip) {
            win_print_old_history((ProfWin*)chatwin, msg);
        } else {
            win_print_history((ProfWin*)chatwin, msg);
        }
        plugins_post_chat_message_display(msg->from_jid->barejid, msg->from_jid->resourcepart, msg->plain);
        msg->plain = old_plain;
        curr = g_slist_next(curr);
    }

    g_slist_free_full(history, (GDestroyNotify)message_free);
    win_redraw((ProfWin*)chatwin);

    return has_items;
}

static void
_chatwin_set_last_message(ProfChatWin* chatwin, const char* const id, const char* const message)
{
    g_set_str(&chatwin->last_message, message);
    g_set_str(&chatwin->last_msg_id, id);
}
