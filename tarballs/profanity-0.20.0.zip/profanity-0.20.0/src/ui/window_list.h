/*
 * window_list.h
 * vim: expandtab:ts=4:sts=4:sw=4
 *
 * Copyright (C) 2012 - 2019 James Booth <boothj5@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later WITH OpenSSL-exception
 */

#ifndef UI_WINDOW_LIST_H
#define UI_WINDOW_LIST_H

#include "ui/ui.h"

void wins_init(void);

ProfWin* wins_new_xmlconsole(void);
ProfWin* wins_new_chat(const gchar* const barejid);
ProfWin* wins_new_muc(const gchar* const roomjid);
ProfWin* wins_new_config(const gchar* const roomjid, DataForm* form, ProfConfWinCallback submit, ProfConfWinCallback cancel, const void* userdata);
ProfWin* wins_new_private(const gchar* const fulljid);
ProfWin* wins_new_plugin(const gchar* const plugin_name, const gchar* const tag);
ProfWin* wins_new_vcard(vCard* vcard);

gboolean wins_chat_exists(const gchar* const barejid);
GList* wins_get_private_chats(const gchar* const roomjid);
void wins_private_nick_change(const gchar* const roomjid, const gchar* const oldnick, const gchar* const newnick);
void wins_change_nick(const gchar* const barejid, const gchar* const oldnick, const gchar* const newnick);
void wins_remove_nick(const gchar* const barejid, const gchar* const oldnick);

ProfWin* wins_get_console(void);
ProfChatWin* wins_get_chat(const gchar* const barejid);
GList* wins_get_chat_unsubscribed(void);
ProfMucWin* wins_get_muc(const gchar* const roomjid);
ProfConfWin* wins_get_conf(const gchar* const roomjid);
ProfPrivateWin* wins_get_private(const gchar* const fulljid);
ProfPluginWin* wins_get_plugin(const gchar* const tag);
ProfXMLWin* wins_get_xmlconsole(void);
ProfVcardWin* wins_get_vcard(void);

void wins_close_plugin(const gchar* const tag);

ProfWin* wins_get_current(void);

void wins_set_current_by_num(int i);

ProfWin* wins_get_by_num(int i);
ProfWin* wins_get_by_string(const gchar* const str);

ProfWin* wins_get_next(void);
ProfWin* wins_get_previous(void);
ProfWin* wins_get_next_unread(void);
ProfWin* wins_get_next_attention(void);
int wins_get_num(ProfWin* window);
int wins_get_current_num(void);
void wins_close_by_num(int i);
gboolean wins_is_current(ProfWin* window);
gboolean wins_do_notify_remind(void);
int wins_get_total_unread(void);
void wins_resize_all(void);
GSList* wins_get_chat_recipients(void);
GSList* wins_get_prune_wins(void);
void wins_lost_connection(void);
void wins_reestablished_connection(void);
void wins_omemo_trust_changed(const gchar* const jid);
gboolean wins_tidy(void);
GSList* wins_create_summary(gboolean unread);
GSList* wins_create_summary_attention(void);
void wins_destroy(void);
GList* wins_get_nums(void);
void wins_swap(int source_win, int target_win);
void wins_hide_subwin(ProfWin* window);
void wins_show_subwin(ProfWin* window);

char* win_autocomplete(const gchar* const search_str, gboolean previous, void* context);
void win_reset_search_attempts(void);
char* win_close_autocomplete(const gchar* const search_str, gboolean previous, void* context);
void win_close_reset_search_attempts(void);

char* wins_get_url(const gchar* const search_str, gboolean previous, void* context);
void wins_reset_url_ac(void);
void wins_add_quotes_ac(const ProfWin* const win, const gchar* const message, const gboolean flip);

#endif
