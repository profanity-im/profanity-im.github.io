/*
 * tray.h
 * vim: expandtab:ts=4:sts=4:sw=4
 *
 * Copyright (C) 2012 - 2019 James Booth <boothj5@gmail.com>
 * Copyright (C) 2026 Michael Vetter <jubalh@iodoru.org>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later WITH OpenSSL-exception
 */

#ifndef UI_TRAY_H
#define UI_TRAY_H

#include <glib.h>

#ifdef HAVE_TRAY
void tray_init(void);
void tray_update(void);
gboolean tray_is_ready(void);
void tray_enable(void);
void tray_disable(void);
void tray_set_timer(int interval);
#endif

#endif
