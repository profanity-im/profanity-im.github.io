/*
 * common.c
 * vim: expandtab:ts=4:sts=4:sw=4
 *
 * Copyright (C) 2012 - 2019 James Booth <boothj5@gmail.com>
 * Copyright (C) 2019 - 2026 Michael Vetter <jubalh@iodoru.org>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later WITH OpenSSL-exception
 */

#include "config.h"

#include <errno.h>
#include <sys/select.h>
#include <assert.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <curl/curl.h>
#include <curl/easy.h>
#include <glib.h>
#include <gio/gio.h>
#include <glib/gstdio.h>

#ifdef HAVE_NCURSESW_NCURSES_H
#include <ncursesw/ncurses.h>
#elif HAVE_NCURSES_H
#include <ncurses.h>
#elif HAVE_CURSES_H
#include <curses.h>
#endif

#include "log.h"
#include "common.h"
#include "config/files.h"
#include "ui/ui.h"

#ifdef HAVE_GIT_VERSION
#include "gitversion.h"
#endif

struct curl_data_t
{
    gchar* buffer;
    size_t size;
};

static size_t _data_callback(void* ptr, size_t size, size_t nmemb, void* data);

/**
 * Frees the memory allocated for a gchar* string.
 *
 * @param str Pointer to the gchar* string to be freed. If NULL, no action is taken.
 */
void
auto_free_gchar(gchar** str)
{
    if (str == NULL)
        return;
    g_free(*str);
}

/**
 * Frees the memory allocated for a guchar* string.
 *
 * @param str Pointer to the guchar* string to be freed. If NULL, no action is taken.
 */
void
auto_free_guchar(guchar** ptr)
{
    if (ptr == NULL) {
        return;
    }
    g_free(*ptr);
}

/**
 * Frees the memory allocated for a gchar** string array.
 *
 * @param args Pointer to the gchar** string array to be freed. If NULL, no action is taken.
 */
void
auto_free_gcharv(gchar*** args)
{
    if (args == NULL)
        return;
    g_strfreev(*args);
}

/**
 * Frees the memory allocated for a char* string.
 *
 * @param str Pointer to the char* string to be freed. If NULL, no action is taken.
 */
void
auto_free_char(char** str)
{
    if (str == NULL)
        return;
    free(*str);
}

/**
 * Closes the file descriptor.
 *
 * @param fd file descriptor handle. If NULL, no action is taken.
 */
void
auto_close_gfd(gint* fd)
{
    if (fd == NULL)
        return;

    GError* error = NULL;
    if (!g_clear_fd(fd, &error)) {
        log_error("Failed closing fd: %s", error->message);
        g_error_free(error);
    }
}

/**
 * Closes file stream
 *
 * @param fd file descriptor handle opened with fopen. If NULL, no action is taken.
 */
void
auto_close_FILE(FILE** fd)
{
    if (fd == NULL)
        return;

    if (fclose(*fd) == EOF)
        log_error(g_strerror(errno));
}

void
auto_free_gerror(GError** err)
{
    if (err == NULL)
        return;

    PROF_GERROR_FREE(*err);
}

static gboolean
_load_keyfile(prof_keyfile_t* keyfile)
{
    auto_gerror GError* error = NULL;
    keyfile->keyfile = g_key_file_new();

    if (g_key_file_load_from_file(keyfile->keyfile, keyfile->filename, G_KEY_FILE_KEEP_COMMENTS | G_KEY_FILE_KEEP_TRANSLATIONS, &error)) {
        return TRUE;
    } else if (error && error->code != G_FILE_ERROR_NOENT) {
        log_warning("[Keyfile] error loading %s: %s", keyfile->filename, error->message);
    } else {
        log_warning("[Keyfile] no such file: %s", keyfile->filename);
    }
    return FALSE;
}

static gchar*
_get_file_or_linked(const gchar* loc)
{
    char* resolved = realpath(loc, NULL);
    if (resolved) {
        gchar* res = g_strdup(resolved);
        free(resolved);
        return res;
    }

    return g_strdup(loc);
}

gboolean
load_data_keyfile(prof_keyfile_t* keyfile, const gchar* filename)
{
    auto_gchar gchar* loc = files_get_data_path(filename);
    return load_custom_keyfile(keyfile, _get_file_or_linked(loc));
}

gboolean
load_config_keyfile(prof_keyfile_t* keyfile, const gchar* filename)
{
    auto_gchar gchar* loc = files_get_config_path(filename);
    return load_custom_keyfile(keyfile, _get_file_or_linked(loc));
}

gboolean
load_custom_keyfile(prof_keyfile_t* keyfile, gchar* filename)
{
    keyfile->filename = filename;

    if (g_file_test(keyfile->filename, G_FILE_TEST_EXISTS)) {
        g_chmod(keyfile->filename, S_IRUSR | S_IWUSR);
    } else {
        int fno = g_creat(keyfile->filename, S_IRUSR | S_IWUSR);
        if (fno != -1)
            g_close(fno, NULL);
    }

    return _load_keyfile(keyfile);
}

gboolean
save_keyfile(prof_keyfile_t* keyfile)
{
    auto_gerror GError* error = NULL;
    if (!g_key_file_save_to_file(keyfile->keyfile, keyfile->filename, &error)) {
        log_error("[Keyfile]: saving file %s failed! %s", STR_MAYBE_NULL(keyfile->filename), PROF_GERROR_MESSAGE(error));
        return FALSE;
    }
    g_chmod(keyfile->filename, S_IRUSR | S_IWUSR);
    return TRUE;
}

void
free_keyfile(prof_keyfile_t* keyfile)
{
    log_debug("[Keyfile]: free %s", STR_MAYBE_NULL(keyfile->filename));
    g_clear_pointer(&keyfile->keyfile, g_key_file_free);
    g_clear_pointer(&keyfile->filename, g_free);
}

gboolean
string_to_verbosity(const gchar* cmd, int* verbosity, gchar** err_msg)
{
    return strtoi_range(cmd, verbosity, 0, 3, err_msg);
}

gboolean
create_dir(const gchar* name)
{
    if (g_mkdir_with_parents(name, S_IRWXU) != 0) {
        log_error("Failed to create directory at '%s' with error '%s'", name, strerror(errno));
        return FALSE;
    }
    return TRUE;
}

gboolean
copy_file(const gchar* const sourcepath, const gchar* const targetpath, const gboolean overwrite_existing)
{
    GFile* source = g_file_new_for_path(sourcepath);
    GFile* dest = g_file_new_for_path(targetpath);
    GFileCopyFlags flags = overwrite_existing ? G_FILE_COPY_OVERWRITE : G_FILE_COPY_NONE;
    gboolean success = g_file_copy(source, dest, flags, NULL, NULL, NULL, NULL);
    g_object_unref(source);
    g_object_unref(dest);
    return success;
}

gboolean
strtoi_range(const gchar* str, int* saveptr, int min, int max, gchar** err_msg)
{
    if (str == NULL) {
        if (err_msg) {
            *err_msg = g_strdup("'str' input pointer can not be NULL");
        }
        return FALSE;
    }

    g_autoptr(GError) error = NULL;
    gint64 val = 0;
    if (!g_ascii_string_to_signed(str, 10, min, max, &val, &error)) {
        if (err_msg) {
            if (g_error_matches(error, G_NUMBER_PARSER_ERROR, G_NUMBER_PARSER_ERROR_OUT_OF_BOUNDS)) {
                *err_msg = g_strdup_printf("Value %s out of range. Must be in %d..%d.", str, min, max);
            } else {
                *err_msg = g_strdup_printf("Could not convert \"%s\" to a number.", str);
            }
        }
        return FALSE;
    }

    *saveptr = (int)val;

    return TRUE;
}

gboolean
string_matches_one_of(const gchar* what, const gchar* is, gboolean is_can_be_null, const gchar* first, ...)
{
    gboolean ret = FALSE;
    va_list ap;
    const gchar* cur = first;
    if (!is)
        return is_can_be_null;

    va_start(ap, first);
    while (cur != NULL) {
        if (g_strcmp0(is, cur) == 0) {
            ret = TRUE;
            break;
        }
        cur = va_arg(ap, const gchar*);
    }
    va_end(ap);
    if (!ret && what) {
        cons_show("Invalid %s: '%s'", what, is);
        gchar errmsg[256] = { 0 };
        size_t sz = 0;
        int s = snprintf(errmsg, sizeof(errmsg) - sz, "%s must be one of:", what);
        if (s < 0 || s + sz >= sizeof(errmsg))
            return ret;
        sz += s;

        cur = first;
        va_start(ap, first);
        while (cur != NULL) {
            const gchar* next = va_arg(ap, const gchar*);
            if (next) {
                s = snprintf(errmsg + sz, sizeof(errmsg) - sz, " '%s',", cur);
            } else {
                /* remove last ',' */
                sz--;
                errmsg[sz] = '\0';
                s = snprintf(errmsg + sz, sizeof(errmsg) - sz, " or '%s'.", cur);
            }
            if (s < 0 || s + sz >= sizeof(errmsg)) {
                log_debug("Error message too long or some other error occurred (%d).", s);
                s = -1;
                break;
            }
            sz += s;
            cur = next;
        }
        va_end(ap);
        if (s > 0)
            cons_show(errmsg);
    }
    return ret;
}

gboolean
valid_tls_policy_option(const gchar* is)
{
    return string_matches_one_of("TLS policy", is, TRUE, "force", "allow", "trust", "disable", "legacy", "direct", NULL);
}

int
utf8_display_len(const gchar* const str)
{
    if (!str) {
        return 0;
    }

    int len = 0;
    gchar* curr = g_utf8_offset_to_pointer(str, 0);
    while (*curr != '\0') {
        gunichar curru = g_utf8_get_char(curr);
        if (g_unichar_iswide(curru)) {
            len += 2;
        } else {
            len++;
        }
        curr = g_utf8_next_char(curr);
    }

    return len;
}

/**
 * Removes illegal XML 1.0 characters from a string.
 *
 * This function creates a new string that excludes characters in the range
 * U+0000 to U+001F, except for U+0009 (TAB), U+000A (LF), and U+000D (CR).
 */
gchar*
str_xml_sanitize(const gchar* const str)
{
    if (str == NULL) {
        return NULL;
    }

    GString* sanitized = g_string_new_len(NULL, strlen(str));
    const gchar* curr = str;

    while (*curr != '\0') {
        gunichar c = g_utf8_get_char(curr);
        if ((c >= 0x20) || (c == 0x09) || (c == 0x0A) || (c == 0x0D)) {
            g_string_append_unichar(sanitized, c);
        }
        curr = g_utf8_next_char(curr);
    }

    return g_string_free_and_steal(sanitized);
}

typedef gboolean (*CharFilterFunc)(gunichar ch);

static void
_str_clean_chars(gchar* str, CharFilterFunc filter_func)
{
    if (str == NULL || filter_func == NULL) {
        return;
    }

    gchar* src = str;
    gchar* dst = str;

    while (*src != '\0') {
        gunichar ch = g_utf8_get_char(src);
        gchar* next = g_utf8_next_char(src);

        if (filter_func(ch)) {
            src = next;
        } else {
            while (src < next) {
                *dst++ = *src++;
            }
        }
    }
    *dst = '\0';
}

static gboolean
_is_directional_char(gunichar ch)
{
    return (ch == 0x061C || ch == 0x200E || ch == 0x200F || (ch >= 0x202A && ch <= 0x202E) || (ch >= 0x2066 && ch <= 0x2069));
}

static gboolean
_is_terminal_control_char(gunichar ch)
{
    return ((ch < 0x20 && ch != '\t' && ch != '\n') || ch == 0x7F || (ch >= 0x80 && ch <= 0x9F));
}

/**
 * Strips Unicode Bidirectional control characters
 * - Marks: U+061C (ALM), U+200E (LRM), U+200F (RLM)
 * - Embeddings & Overrides: U+202A (LRE) through U+202E (RLO)
 * - Isolates: U+2066 (LRI) through U+2069 (PDI)
 */
void
str_clean_directional_chars(gchar* str)
{
    _str_clean_chars(str, _is_directional_char);
}

/**
 * Strips terminal control characters
 * - C0 control characters (0x01 - 0x1F), preserving 0x09 (\t) and 0x0A (\n).
 * - ASCII DEL (0x7F).
 * - C1 control characters (U+0080 - U+009F).
 *
 * Certain sequences are allowed by XML and can occur in normal
 * messages: entity-encoded carriage return (&#xD; / \r), DEL (0x7F), and C1
 * controls (U+0080 - U+009F).
 * OTR and PGP decrypt arbitrary raw bytes directly into message->plain without
 * passing through an XML parser, allowing ANSI escape sequences to bypass XML
 * validation.
 */
void
str_clean_terminal_control_chars(gchar* str)
{
    _str_clean_chars(str, _is_terminal_control_char);
}

gint
str_ascii_casecmp0(const gchar* s1, const gchar* s2)
{
    if (s1 == s2) {
        return 0;
    }
    if (s1 == NULL) {
        return -1;
    }
    if (s2 == NULL) {
        return 1;
    }
    return g_ascii_strcasecmp(s1, s2);
}

gchar*
release_get_latest(void)
{
    const gchar* url = "https://profanity-im.github.io/profanity_version.txt";

    CURL* handle = curl_easy_init();
    struct curl_data_t output;
    output.buffer = NULL;
    output.size = 0;

    curl_easy_setopt(handle, CURLOPT_URL, url);
    curl_easy_setopt(handle, CURLOPT_WRITEFUNCTION, _data_callback);
    curl_easy_setopt(handle, CURLOPT_TIMEOUT, (long)2);
    curl_easy_setopt(handle, CURLOPT_WRITEDATA, (void*)&output);

    curl_easy_perform(handle);
    curl_easy_cleanup(handle);

    if (output.buffer) {
        output.buffer[output.size++] = '\0';
        return output.buffer;
    } else {
        return NULL;
    }
}

gboolean
release_is_new(const gchar* const curr_version, const gchar* const found_version)
{
    if (!curr_version || !found_version) {
        return FALSE;
    }

    int curr_maj, curr_min, curr_patch, found_maj, found_min, found_patch;

    int parse_curr = sscanf(curr_version, "%d.%d.%d", &curr_maj, &curr_min,
                            &curr_patch);
    int parse_found = sscanf(found_version, "%d.%d.%d", &found_maj, &found_min,
                             &found_patch);

    if (parse_found == 3 && parse_curr == 3) {
        if (found_maj > curr_maj) {
            return TRUE;
        } else if (found_maj == curr_maj && found_min > curr_min) {
            return TRUE;
        } else if (found_maj == curr_maj && found_min == curr_min
                   && found_patch > curr_patch) {
            return TRUE;
        } else {
            return FALSE;
        }
    } else {
        return FALSE;
    }
}

static size_t
_data_callback(void* ptr, size_t size, size_t nmemb, void* data)
{
    size_t realsize = size * nmemb;
    struct curl_data_t* mem = (struct curl_data_t*)data;
    mem->buffer = g_realloc(mem->buffer, mem->size + realsize + 1);

    if (mem->buffer) {
        memcpy(&(mem->buffer[mem->size]), ptr, realsize);
        mem->size += realsize;
        mem->buffer[mem->size] = 0;
    }

    return realsize;
}

gchar*
strip_arg_quotes(const gchar* const input)
{
    if (input == NULL) {
        return NULL;
    }

    if (strchr(input, '"') == NULL && strchr(input, '\\') == NULL) {
        return g_strdup(input);
    }

    // Unescape and strip quotes
    GString* unescaped = g_string_new("");
    for (const gchar* p = input; *p; p++) {
        if (*p == '\\' && (*(p + 1) != '\0')) {
            p++;
            g_string_append_c(unescaped, *p);
        } else if (*p == '"') {
            // Only strip if it's the first char or preceded by a space
            if (p == input || *(p - 1) == ' ') {
                continue;
            }
            // Or if it's the last char
            if (*(p + 1) == '\0') {
                continue;
            }
            g_string_append_c(unescaped, *p);
        } else {
            g_string_append_c(unescaped, *p);
        }
    }

    return g_string_free_and_steal(unescaped);
}

gboolean
is_notify_enabled(void)
{
    gboolean notify_enabled = FALSE;

#ifdef HAVE_OSXNOTIFY
    notify_enabled = TRUE;
#endif
#ifdef HAVE_NOTIFICATIONS
    notify_enabled = TRUE;
#endif
#ifdef PLATFORM_CYGWIN
    notify_enabled = TRUE;
#endif

    return notify_enabled;
}

GSList*
prof_occurrences(const gchar* const needle, const gchar* const haystack, int offset, gboolean whole_word, GSList** result)
{
    if (needle == NULL || haystack == NULL || *needle == '\0') {
        return *result;
    }

    size_t needle_len = strlen(needle);
    gchar* p = g_utf8_offset_to_pointer(haystack, offset);
    GSList* matches = NULL;

    while (p) {
        if (g_str_has_prefix(p, needle)) {
            if (whole_word) {
                gunichar before = 0;
                gchar* haystack_before_ch = g_utf8_find_prev_char(haystack, p);
                if (haystack_before_ch) {
                    before = g_utf8_get_char(haystack_before_ch);
                }

                gunichar after = 0;
                gchar* haystack_after_ch = p + needle_len;
                if (*haystack_after_ch != '\0') {
                    after = g_utf8_get_char(haystack_after_ch);
                }

                if (!g_unichar_isalnum(before) && !g_unichar_isalnum(after)) {
                    matches = g_slist_prepend(matches, GINT_TO_POINTER(offset));
                }
            } else {
                matches = g_slist_prepend(matches, GINT_TO_POINTER(offset));
            }
        }

        if (*p == '\0') {
            break;
        }

        p = g_utf8_next_char(p);
        offset++;
    }

    if (matches) {
        *result = g_slist_concat(*result, g_slist_reverse(matches));
    }

    return *result;
}

gchar*
get_random_string(int length)
{
    gchar* rand = g_malloc0(length + 1);
    const gchar alphabet[] = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    int endrange = sizeof(alphabet) - 1;

    for (int i = 0; i < length; i++) {
        rand[i] = alphabet[g_random_int_range(0, endrange)];
    }

    return rand;
}

GSList*
get_mentions(gboolean whole_word, gboolean case_sensitive, const gchar* const message, const gchar* const nick)
{
    GSList* mentions = NULL;

    if (message == NULL || nick == NULL) {
        return NULL;
    }

    if (case_sensitive) {
        return prof_occurrences(nick, message, 0, whole_word, &mentions);
    }

    auto_gchar gchar* message_lower = g_utf8_strdown(message, -1);
    auto_gchar gchar* nick_lower = g_utf8_strdown(nick, -1);

    return prof_occurrences(nick_lower, message_lower, 0, whole_word, &mentions);
}

gboolean
call_external(gchar** argv)
{
    auto_gerror GError* spawn_error = NULL;
    gboolean is_successful;

    GSpawnFlags flags = G_SPAWN_SEARCH_PATH | G_SPAWN_STDOUT_TO_DEV_NULL | G_SPAWN_STDERR_TO_DEV_NULL;

    is_successful = g_spawn_async(NULL, // Inherit the parent PWD
                                  argv,
                                  NULL, // Inherit the parent environment
                                  flags,
                                  NULL, NULL, NULL,
                                  &spawn_error);
    if (!is_successful) {
        auto_gchar gchar* cmd = g_strjoinv(" ", argv);
        log_error("Spawning '%s' failed with error '%s'", cmd, PROF_GERROR_MESSAGE(spawn_error));
    }

    return is_successful;
}

/**
 * @brief Formats an argument vector for calling an external command with placeholders.
 *
 * This function constructs an argument vector (argv) based on the provided template string, replacing placeholders ("%u" and "%p") with the provided URL and filename, respectively.
 *
 * @param template  The template string with placeholders.
 * @param url       The URL to replace "%u" (or NULL to skip).
 * @param filename  The filename to replace "%p" (or NULL to skip).
 * @return          The constructed argument vector (argv) as a null-terminated array of strings.
 *
 * @note Remember to free the returned argument vector using `auto_gcharv` or `g_strfreev()`.
 */
gchar**
format_call_external_argv(const gchar* template, const gchar* url, const gchar* filename)
{
    gchar** argv = g_strsplit(template, " ", 0);

    guint num_args = 0;
    while (argv[num_args]) {
        if (0 == g_strcmp0(argv[num_args], "%u") && url != NULL) {
            g_free(argv[num_args]);
            argv[num_args] = g_strdup(url);
        } else if (0 == g_strcmp0(argv[num_args], "%p") && filename != NULL) {
            g_free(argv[num_args]);
            argv[num_args] = g_strdup(filename);
        }
        num_args++;
    }

    return argv;
}

static gchar*
_unique_filename(const gchar* filename)
{
    gchar* unique = g_strdup(filename);

    unsigned int i = 0;
    while (g_file_test(unique, G_FILE_TEST_EXISTS)) {
        g_free(unique);

        if (i > 1000) { // Give up after 1000 attempts.
            return NULL;
        }

        unique = g_strdup_printf("%s.%u", filename, i);
        if (!unique) {
            return NULL;
        }

        i++;
    }

    return unique;
}

static gboolean
_has_directory_suffix(const gchar* path)
{
    return (g_str_has_suffix(path, ".")
            || g_str_has_suffix(path, "..")
            || g_str_has_suffix(path, G_DIR_SEPARATOR_S));
}

/**
 * @brief Extracts the basename from a given URL.
 *
 * @param url The URL to extract the basename from.
 * @return The extracted basename or a default name ("index") if the basename has a directory suffix.
 *
 * @note Remember to free the returned value using `auto_gchar` or `g_free()`.
 */
gchar*
basename_from_url(const gchar* url)
{
    const gchar* default_name = "index";

    GFile* file = g_file_new_for_commandline_arg(url);
    auto_gchar gchar* basename = g_file_get_basename(file);
    g_object_unref(file);

    if (_has_directory_suffix(basename)) {
        return g_strdup(default_name);
    }

    return g_strdup(basename);
}

/**
 * Expands the provided path by resolving special characters like '~' and 'file://'.
 *
 * @param path The path to expand.
 * @return The expanded path.
 *
 * @note Remember to free the returned value using `auto_gchar` or `g_free()`.
 */
gchar*
get_expanded_path(const gchar* path)
{
    if (path == NULL) {
        return NULL;
    }

    if (g_str_has_prefix(path, "file://")) {
        path += strlen("file://");
    }

    if (g_str_has_prefix(path, "~/")) {
        return g_build_filename(g_get_home_dir(), path + 2, NULL);
    }

    return g_strdup(path);
}

/**
 * Generates a unique filename based on the provided URL and path.
 *
 * @param url The URL to derive the basename from.
 * @param path The path to prepend to the generated filename. If NULL, the current directory is used.
 * @return A unique filename combining the path and derived basename from the URL.
 *
 * @note Remember to free the returned value using `auto_gchar` or `g_free()`.
 */
gchar*
unique_filename_from_url(const gchar* url, const gchar* path)
{
    auto_gchar gchar* realpath = NULL;

    // Default to './' as path when none has been provided.
    if (path == NULL) {
        realpath = g_strdup("./");
    } else {
        realpath = get_expanded_path(path);
    }

    // Resolves paths such as './../.' for path.
    GFile* target = g_file_new_for_commandline_arg(realpath);
    auto_gchar gchar* filename = NULL;

    if (_has_directory_suffix(realpath) || g_file_test(realpath, G_FILE_TEST_IS_DIR)) {
        // The target should be used as a directory. Assume that the basename
        // should be derived from the URL.
        auto_gchar gchar* basename = basename_from_url(url);
        filename = g_build_filename(g_file_peek_path(target), basename, NULL);
    } else {
        // Just use the target as filename.
        filename = g_build_filename(g_file_peek_path(target), NULL);
    }

    gchar* unique_filename = _unique_filename(filename);
    if (unique_filename == NULL) {
        return NULL;
    }

    g_object_unref(target);

    return unique_filename;
}

/* This returns a timestamp formatted in ISO8601 format.
 * Either it returns the current time if `dt` is NULL, or
 * it returns the formatted time value passed in `dt`.
 */
gchar*
prof_date_time_format_iso8601(GDateTime* dt)
{
    GDateTime* dt_ = (dt == NULL) ? g_date_time_new_now_local() : dt;
    gchar* ret = g_date_time_format_iso8601(dt_);
    if (dt == NULL)
        g_date_time_unref(dt_);
    return ret;
}

/* build profanity version string.
 * example: 0.13.1dev.master.69d8c1f9
 */
gchar*
prof_get_version(void)
{
#ifdef PACKAGE_STATUS_DEVELOPMENT
#ifdef HAVE_GIT_VERSION
    return g_strdup_printf("%sdev.%s.%s", PACKAGE_VERSION, PROF_GIT_BRANCH, PROF_GIT_REVISION);
#else
    return g_strdup_printf("%sdev", PACKAGE_VERSION);
#endif
#else
    return g_strdup_printf("%s", PACKAGE_VERSION);
#endif
}

void
prof_wipe_string(gchar* str)
{
    if (str) {
        volatile gchar* p = (volatile gchar*)str;
        while (*p) {
            *p++ = 0;
        }
    }
}
