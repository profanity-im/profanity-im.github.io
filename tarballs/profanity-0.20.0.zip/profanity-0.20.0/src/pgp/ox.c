/*
 * ox.c
 * vim: expandtab:ts=4:sts=4:sw=4
 *
 * Copyright (C) 2020 Stefan Kropp <stefan@debxwoody.de>
 * Copyright (C) 2020 - 2026 Michael Vetter <jubalh@iodoru.org>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later WITH OpenSSL-exception
 */

#include "config.h"

#include <locale.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>

#include <glib.h>
#include <glib/gstdio.h>
#include <gpgme.h>

#include "log.h"
#include "common.h"
#include "pgp/ox.h"
#include "config/files.h"
#include "ui/ui.h"

static gpgme_key_t _ox_key_lookup(const gchar* const barejid, gboolean secret_only);
static gboolean _ox_key_is_usable(gpgme_key_t key, const gchar* const barejid, gboolean secret);
static GHashTable* _ox_gpg_get_keys(gboolean check_secret);

static GHashTable*
_ox_gpg_get_keys(gboolean check_secret)
{
    gpgme_error_t error;
    GHashTable* result = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, (GDestroyNotify)p_gpg_free_key);

    gpgme_ctx_t ctx;
    error = gpgme_new(&ctx);

    if (error) {
        log_error("OX: Failed to create gpgme context. %s %s", gpgme_strsource(error), gpgme_strerror(error));
        return NULL;
    }

    error = gpgme_op_keylist_start(ctx, NULL, 0); // all public keys
    if (error == GPG_ERR_NO_ERROR) {
        gpgme_key_t key;
        error = gpgme_op_keylist_next(ctx, &key);
        if (error != GPG_ERR_EOF && error != GPG_ERR_NO_ERROR) {
            log_error("OX: gpgme_op_keylist_next %s %s", gpgme_strsource(error), gpgme_strerror(error));
            g_hash_table_destroy(result);
            gpgme_release(ctx);
            return NULL;
        }
        while (!error) {
            // Looking for XMPP URI UID
            gpgme_user_id_t uid = key->uids;
            gpgme_user_id_t xmppid = NULL;
            while (!xmppid && uid) {
                if (uid->name && strlen(uid->name) >= 10) {
                    if (strstr(uid->name, "xmpp:") == uid->name) {
                        xmppid = uid;
                    }
                }
                uid = uid->next;
            }

            if (xmppid) {
                // Build Key information about all subkey
                gpgme_subkey_t sub = key->subkeys;

                ProfPGPKey* p_pgpkey = p_gpg_key_new();
                p_pgpkey->id = g_strdup(sub->keyid);
                p_pgpkey->name = g_strdup(xmppid->uid);
                p_pgpkey->fp = g_strdup(sub->fpr);
                if (sub->can_encrypt)
                    p_pgpkey->encrypt = TRUE;
                if (sub->can_authenticate)
                    p_pgpkey->authenticate = TRUE;
                if (sub->can_certify)
                    p_pgpkey->certify = TRUE;
                if (sub->can_sign)
                    p_pgpkey->sign = TRUE;

                sub = sub->next;
                while (sub) {
                    if (sub->can_encrypt)
                        p_pgpkey->encrypt = TRUE;
                    if (sub->can_authenticate)
                        p_pgpkey->authenticate = TRUE;
                    if (sub->can_certify)
                        p_pgpkey->certify = TRUE;
                    if (sub->can_sign)
                        p_pgpkey->sign = TRUE;

                    sub = sub->next;
                }

                g_hash_table_insert(result, g_strdup(p_pgpkey->name), p_pgpkey);
            }
            gpgme_key_unref(key);
            error = gpgme_op_keylist_next(ctx, &key);
        }
    }

    if (check_secret) {
        // Pass 2: Check if any of these public keys also has a corresponding secret key
        error = gpgme_op_keylist_start(ctx, NULL, 1); // 1 = secret/private keys
        if (error == GPG_ERR_NO_ERROR) {
            gpgme_key_t key;
            error = gpgme_op_keylist_next(ctx, &key);
            while (!error) {
                gpgme_subkey_t sub = key->subkeys;
                while (sub) {
                    if (sub->secret) {
                        // Match by fingerprint
                        GList* values = g_hash_table_get_values(result);
                        GList* curr = values;
                        while (curr) {
                            ProfPGPKey* pkey = curr->data;
                            if (g_strcmp0(pkey->fp, sub->fpr) == 0) {
                                pkey->secret = TRUE;
                                break;
                            }
                            curr = curr->next;
                        }
                        g_list_free(values);
                    }
                    sub = sub->next;
                }

                gpgme_key_unref(key);
                error = gpgme_op_keylist_next(ctx, &key);
            }
        }
    }

    gpgme_release(ctx);

    return result;
}

/*!
 * \brief Public keys with XMPP-URI.
 *
 * This function will look for all public key with a XMPP-URI as UID.
 *
 * @returns GHashTable* with GString* xmpp-uri and ProfPGPKey* value. Empty
 * hash, if there is no key. NULL in case of error.
 *
 */
GHashTable*
ox_gpg_public_keys(void)
{
    return _ox_gpg_get_keys(FALSE);
}

/*!
 * \brief List all keys with XMPP-URI and check their secret status.
 *
 * This function will look for all keys with a XMPP-URI as UID and determine if
 * they have private counterparts.
 *
 * @returns GHashTable* with GString* xmpp-uri and ProfPGPKey* value. Empty
 * hash, if there is no key. NULL in case of error.
 *
 */
GHashTable*
ox_gpg_list_keys(void)
{
    return _ox_gpg_get_keys(TRUE);
}

gchar*
p_ox_gpg_signcrypt(const gchar* const sender_barejid, const gchar* const recipient_barejid, const gchar* const message)
{
    gchar* result = NULL;
    gpgme_ctx_t ctx = NULL;
    gpgme_key_t recp[3] = { NULL, NULL, NULL };
    gpgme_data_t plain = NULL;
    gpgme_data_t cipher = NULL;
    char* cipher_str = NULL;

    setlocale(LC_ALL, "");
    gpgme_check_version(NULL);
    gpgme_set_locale(NULL, LC_CTYPE, setlocale(LC_CTYPE, NULL));

    gpgme_error_t error = gpgme_new(&ctx);
    if (GPG_ERR_NO_ERROR != error) {
        log_error("OX: Failed to create gpgme context. %s %s", gpgme_strsource(error), gpgme_strerror(error));
        return NULL;
    }

    error = gpgme_set_protocol(ctx, GPGME_PROTOCOL_OPENPGP);
    if (error != 0) {
        log_error("OX: Signcrypt error: %s", gpgme_strerror(error));
    }

    gpgme_set_armor(ctx, 0);
    gpgme_set_textmode(ctx, 0);
    gpgme_set_offline(ctx, 1);
    gpgme_set_keylist_mode(ctx, GPGME_KEYLIST_MODE_LOCAL);

    gchar* xmpp_jid_me = g_strconcat("xmpp:", sender_barejid, NULL);
    gchar* xmpp_jid_recipient = g_strconcat("xmpp:", recipient_barejid, NULL);

    gpgme_signers_clear(ctx);

    // lookup own key
    recp[0] = _ox_key_lookup(sender_barejid, TRUE);
    if (recp[0] == NULL) {
        cons_show_error("Can't find OX key for %s", xmpp_jid_me);
        log_error("OX: Key not found for %s.", xmpp_jid_me);
        goto cleanup;
    }

    error = gpgme_signers_add(ctx, recp[0]);
    if (error != 0) {
        log_error("OX: gpgme_signers_add %s. Error: %s", xmpp_jid_me, gpgme_strerror(error));
        goto cleanup;
    }

    // lookup key of recipient
    recp[1] = _ox_key_lookup(recipient_barejid, FALSE);
    if (recp[1] == NULL) {
        cons_show_error("Can't find OX key for %s", xmpp_jid_recipient);
        log_error("OX: Key not found for %s.", xmpp_jid_recipient);
        goto cleanup;
    }

    recp[2] = NULL;
    if (recp[0]->uids) {
        log_debug("OX: %s <%s>", recp[0]->uids->name, recp[0]->uids->email);
    }
    if (recp[1]->uids) {
        log_debug("OX: %s <%s>", recp[1]->uids->name, recp[1]->uids->email);
    }

    gpgme_encrypt_flags_t flags = 0;

    error = gpgme_data_new_from_mem(&plain, message, strlen(message), 0);
    if (error != 0) {
        log_error("OX: %s", gpgme_strerror(error));
        goto cleanup;
    }

    error = gpgme_data_new(&cipher);
    if (error != 0) {
        log_error("OX: %s", gpgme_strerror(error));
        goto cleanup;
    }

    error = gpgme_op_encrypt_sign(ctx, recp, flags, plain, cipher);
    if (error != 0) {
        log_error("OX: %s", gpgme_strerror(error));
        goto cleanup;
    }

    size_t len;
    cipher_str = gpgme_data_release_and_get_mem(cipher, &len);
    cipher = NULL; // Already released by gpgme_data_release_and_get_mem
    result = g_base64_encode((unsigned char*)cipher_str, len);

cleanup:
    g_free(xmpp_jid_me);
    g_free(xmpp_jid_recipient);
    if (cipher_str)
        gpgme_free(cipher_str);
    if (plain)
        gpgme_data_release(plain);
    if (cipher)
        gpgme_data_release(cipher);
    if (recp[0])
        gpgme_key_release(recp[0]);
    if (recp[1])
        gpgme_key_release(recp[1]);
    if (ctx)
        gpgme_release(ctx);

    return result;
}

gboolean
ox_is_private_key_available(const gchar* const barejid)
{
    g_assert(barejid);
    gboolean result = FALSE;

    gpgme_key_t key = _ox_key_lookup(barejid, TRUE);
    if (key) {
        if (_ox_key_is_usable(key, barejid, TRUE)) {
            result = TRUE;
        }
        gpgme_key_unref(key);
    }

    return result;
}

gboolean
ox_is_public_key_available(const gchar* const barejid)
{
    g_assert(barejid);
    gboolean result = FALSE;
    gpgme_key_t key = _ox_key_lookup(barejid, FALSE);
    if (key) {
        if (_ox_key_is_usable(key, barejid, FALSE)) {
            result = TRUE;
        }
        gpgme_key_unref(key);
    }
    return result;
}

static gpgme_key_t
_ox_key_lookup(const gchar* const barejid, gboolean secret_only)
{
    g_assert(barejid);
    log_debug("OX: Looking for %s key: %s", secret_only == TRUE ? "Private" : "Public", barejid);
    gpgme_key_t key = NULL;
    gpgme_error_t error;

    gpgme_ctx_t ctx;
    error = gpgme_new(&ctx);

    if (error) {
        log_error("OX: gpgme_new failed: %s %s", gpgme_strsource(error), gpgme_strerror(error));
        return NULL;
    }

    error = gpgme_op_keylist_start(ctx, NULL, secret_only);
    if (error == GPG_ERR_NO_ERROR) {
        error = gpgme_op_keylist_next(ctx, &key);
        if (error != GPG_ERR_EOF && error != GPG_ERR_NO_ERROR) {
            log_error("OX: gpgme_op_keylist_next %s %s", gpgme_strsource(error), gpgme_strerror(error));
            return NULL;
        }

        GString* xmppuri = g_string_new("xmpp:");
        g_string_append(xmppuri, barejid);

        while (!error) {
            // Looking for XMPP URI UID
            gpgme_user_id_t uid = key->uids;

            while (uid) {
                if (uid->name && strlen(uid->name) >= 10) {
                    if (g_strcmp0(uid->name, xmppuri->str) == 0) {
                        gpgme_release(ctx);
                        g_string_free(xmppuri, TRUE);
                        return key;
                    }
                }
                uid = uid->next;
            }
            gpgme_key_unref(key);
            error = gpgme_op_keylist_next(ctx, &key);
        }
        g_string_free(xmppuri, TRUE);
    }
    gpgme_release(ctx);

    return key;
}

static gboolean
_ox_key_is_usable(gpgme_key_t key, const gchar* const barejid, gboolean secret)
{
    gboolean result = TRUE;

    if (key->revoked || key->expired || key->disabled) {
        cons_show_error("%s's key is revoked, expired or disabled", barejid);
        log_info("OX:  %s's key is revoked, expired or disabled", barejid);
        result = FALSE;
    }

    // This might be a nice features but AFAIK is not defined in the XEP.
    // If we add this we need to expand our documentation on how to set the
    // trust leven in gpg. I'll add an example to this commit body.
    /*
    if (key->owner_trust < GPGME_VALIDITY_MARGINAL) {
        cons_show_error(" %s's key is has a trust level lower than marginal", barejid);
        log_info("OX: Owner trust of %s's key is < GPGME_VALIDITY_MARGINAL", barejid);
        result = FALSE;
    }
    */

    return result;
}

/*!
 * @brief XMPP-OX: Decrypt OX Message.
 *
 * @param base64  base64_encode OpenPGP message.
 *
 * @result decrypt XMPP OX Message NULL terminated C-String
 */
gchar*
p_ox_gpg_decrypt(const gchar* base64)
{
    gchar* result = NULL;
    gpgme_ctx_t ctx = NULL;
    gpgme_data_t plain = NULL;
    gpgme_data_t cipher = NULL;
    guchar* encrypted = NULL;
    char* plain_str = NULL;

    // if there is no private key avaibale,
    // we don't try do decrypt
    if (!ox_is_private_key_available(connection_get_barejid())) {
        return NULL;
    }
    setlocale(LC_ALL, "");
    gpgme_check_version(NULL);
    gpgme_set_locale(NULL, LC_CTYPE, setlocale(LC_CTYPE, NULL));
    gpgme_error_t error = gpgme_new(&ctx);

    if (GPG_ERR_NO_ERROR != error) {
        log_error("OX: gpgme_new failed: %s %s", gpgme_strsource(error), gpgme_strerror(error));
        return NULL;
    }

    error = gpgme_set_protocol(ctx, GPGME_PROTOCOL_OPENPGP);
    if (error != 0) {
        log_error("OX: %s", gpgme_strerror(error));
    }

    gpgme_set_armor(ctx, 0);
    gpgme_set_textmode(ctx, 0);
    gpgme_set_offline(ctx, 1);
    gpgme_set_keylist_mode(ctx, GPGME_KEYLIST_MODE_LOCAL);

    gsize s;
    encrypted = g_base64_decode(base64, &s);
    error = gpgme_data_new_from_mem(&cipher, (char*)encrypted, s, 0);
    if (error != 0) {
        log_error("OX: gpgme_data_new_from_mem: %s", gpgme_strerror(error));
        goto cleanup;
    }

    error = gpgme_data_new(&plain);
    if (error != 0) {
        log_error("OX: %s", gpgme_strerror(error));
        goto cleanup;
    }

    error = gpgme_op_decrypt_verify(ctx, cipher, plain);
    if (error != 0) {
        log_error("OX: gpgme_op_decrypt: %s", gpgme_strerror(error));
        error = gpgme_op_decrypt(ctx, cipher, plain);
        if (error != 0) {
            goto cleanup;
        }
    }

    size_t len;
    plain_str = gpgme_data_release_and_get_mem(plain, &len);
    plain = NULL; // Already released by gpgme_data_release_and_get_mem
    if (plain_str) {
        result = g_strndup(plain_str, len);
    }

cleanup:
    if (encrypted)
        g_free(encrypted);
    if (plain_str)
        gpgme_free(plain_str);
    if (plain)
        gpgme_data_release(plain);
    if (cipher)
        gpgme_data_release(cipher);
    if (ctx)
        gpgme_release(ctx);

    return result;
}

/*!
 * \brief Read public key from file.
 *
 * This function is used the read a public key from a file.
 *
 * This function is used to read a key and push it on PEP. There are some checks
 * in this function:
 *
 * Key is not
 * - gkey->revoked
 * - gkey->expired
 * - gkey->disabled
 * - gkey->invalid
 * - gkey->secret
 *
 * Only one key in the file.
 *
 * \param filename filename to read the file.
 * \param key result with base64 encode key or NULL
 * \param fp result with the fingerprint or NULL
 *
 */
void
p_ox_gpg_readkey(const gchar* const filename, gchar** key, gchar** fp)
{
    log_info("PX: Read OpenPGP Key from file %s", filename);

    GError* gerr = NULL;
    gchar* data = NULL;
    gsize size = -1;
    gpgme_ctx_t ctx = NULL;
    gpgme_data_t gpgme_data = NULL;
    gpgme_key_t gkey = NULL;
    gpgme_key_t end = NULL;

    gboolean success = g_file_get_contents(filename,
                                           &data,
                                           &size,
                                           &gerr);
    if (success) {
        setlocale(LC_ALL, "");
        gpgme_check_version(NULL);
        gpgme_set_locale(NULL, LC_CTYPE, setlocale(LC_CTYPE, NULL));
        gpgme_error_t error = gpgme_new(&ctx);

        if (GPG_ERR_NO_ERROR != error) {
            log_error("OX: Read OpenPGP key from file: gpgme_new failed: %s", gpgme_strerror(error));
            goto cleanup;
        }

        error = gpgme_set_protocol(ctx, GPGME_PROTOCOL_OPENPGP);
        if (error != GPG_ERR_NO_ERROR) {
            log_error("OX: Read OpenPGP key from file: set GPGME_PROTOCOL_OPENPGP:  %s", gpgme_strerror(error));
            goto cleanup;
        }

        gpgme_set_armor(ctx, 0);
        gpgme_set_textmode(ctx, 0);
        gpgme_set_offline(ctx, 1);
        gpgme_set_keylist_mode(ctx, GPGME_KEYLIST_MODE_LOCAL);

        error = gpgme_data_new_from_mem(&gpgme_data, (char*)data, size, 0);
        if (error != GPG_ERR_NO_ERROR) {
            log_error("OX: Read OpenPGP key from file: gpgme_data_new_from_mem %s", gpgme_strerror(error));
            goto cleanup;
        }
        error = gpgme_op_keylist_from_data_start(ctx, gpgme_data, 0);
        if (error != GPG_ERR_NO_ERROR) {
            log_error("OX: Read OpenPGP key from file: gpgme_op_keylist_from_data_start %s", gpgme_strerror(error));
            goto cleanup;
        }
        error = gpgme_op_keylist_next(ctx, &gkey);
        if (error != GPG_ERR_NO_ERROR) {
            log_error("OX: Read OpenPGP key from file: gpgme_op_keylist_next %s", gpgme_strerror(error));
            goto cleanup;
        }

        error = gpgme_op_keylist_next(ctx, &end);
        if (error == GPG_ERR_NO_ERROR) {
            log_error("OX: Read OpenPGP key from file: ambiguous key");
            goto cleanup;
        }

        if (gkey->revoked || gkey->expired || gkey->disabled || gkey->invalid || gkey->secret) {
            log_error("OX: Read OpenPGP key from file: Key is not valid");
            goto cleanup;
        }

        *key = g_base64_encode((const guchar*)data, size);
        *fp = g_strdup(gkey->fpr);
    } else {
        log_error("OX: Read OpenPGP key from file: Unable to read file: %s", gerr->message);
        g_error_free(gerr);
    }

cleanup:
    if (data)
        g_free(data);
    if (gpgme_data)
        gpgme_data_release(gpgme_data);
    if (gkey)
        gpgme_key_unref(gkey);
    if (end)
        gpgme_key_unref(end);
    if (ctx)
        gpgme_release(ctx);
}

gboolean
p_ox_gpg_import(const gchar* base64_public_key)
{
    gsize size = -1;
    guchar* key = g_base64_decode(base64_public_key, &size);
    gboolean result = TRUE;

    setlocale(LC_ALL, "");
    gpgme_check_version(NULL);
    gpgme_set_locale(NULL, LC_CTYPE, setlocale(LC_CTYPE, NULL));
    gpgme_ctx_t ctx = NULL;
    gpgme_data_t gpgme_data = NULL;
    gpgme_error_t error = gpgme_new(&ctx);

    if (GPG_ERR_NO_ERROR != error) {
        log_error("OX: Read OpenPGP key from file: gpgme_new failed: %s", gpgme_strerror(error));
        result = FALSE;
        goto cleanup;
    }

    error = gpgme_set_protocol(ctx, GPGME_PROTOCOL_OPENPGP);
    if (error != GPG_ERR_NO_ERROR) {
        log_error("OX: Read OpenPGP key from file: set GPGME_PROTOCOL_OPENPGP:  %s", gpgme_strerror(error));
        result = FALSE;
        goto cleanup;
    }

    gpgme_set_armor(ctx, 0);
    gpgme_set_textmode(ctx, 0);
    gpgme_set_offline(ctx, 1);
    gpgme_set_keylist_mode(ctx, GPGME_KEYLIST_MODE_LOCAL);

    error = gpgme_data_new_from_mem(&gpgme_data, (gchar*)key, size, 0);
    if (error != GPG_ERR_NO_ERROR) {
        log_error("OX: Read OpenPGP key from file: gpgme_data_new_from_mem %s", gpgme_strerror(error));
        result = FALSE;
        goto cleanup;
    }

    error = gpgme_op_import(ctx, gpgme_data);
    if (error != GPG_ERR_NO_ERROR) {
        log_error("OX: Failed to import key");
        result = FALSE;
    }

cleanup:
    if (key)
        g_free(key);
    if (gpgme_data)
        gpgme_data_release(gpgme_data);
    if (ctx)
        gpgme_release(ctx);

    return result;
}
