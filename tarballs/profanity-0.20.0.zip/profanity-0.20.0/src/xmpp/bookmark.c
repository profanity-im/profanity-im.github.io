/*
 * bookmark.c
 * vim: expandtab:ts=4:sts=4:sw=4
 *
 * Copyright (C) 2012 - 2019 James Booth <boothj5@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later WITH OpenSSL-exception
 */

#include "config.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <glib.h>

#include <strophe.h>

#include "common.h"
#include "log.h"
#include "event/server_events.h"
#include "plugins/plugins.h"
#include "ui/ui.h"
#include "xmpp/connection.h"
#include "xmpp/iq.h"
#include "xmpp/stanza.h"
#include "xmpp/xmpp.h"
#include "xmpp/bookmark.h"
#include "xmpp/muc.h"

#define BOOKMARK_TIMEOUT 5000

static Autocomplete bookmark_ac;
static GHashTable* bookmarks;

// id handlers
static int _bookmark_result_id_handler(xmpp_stanza_t* const stanza, void* const userdata);

static void _bookmark_destroy(Bookmark* bookmark);
static void _send_bookmarks(void);

static void
_bookmark_shutdown(void)
{
    if (bookmarks) {
        g_hash_table_destroy(bookmarks);
    }
    autocomplete_free(bookmark_ac);
}

void
bookmark_request(void)
{
    prof_add_shutdown_routine(_bookmark_shutdown);
    if (bookmarks) {
        g_hash_table_destroy(bookmarks);
    }
    bookmarks = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, (GDestroyNotify)_bookmark_destroy);

    autocomplete_free(bookmark_ac);
    bookmark_ac = autocomplete_new();

    char* id = "bookmark_init_request";
    iq_id_handler_add(id, _bookmark_result_id_handler, free, NULL);

    xmpp_ctx_t* ctx = connection_get_ctx();
    xmpp_stanza_t* iq = stanza_create_bookmarks_storage_request(ctx);
    xmpp_stanza_set_id(iq, id);

    iq_send_stanza(iq);
    xmpp_stanza_release(iq);
}

gboolean
bookmark_add(const char* jid, const char* nick, const char* password, const char* autojoin_str, const char* name)
{
    if (jid == NULL || !jid_is_valid_user_jid(jid) || g_utf8_strchr(jid, -1, '/') != NULL) {
        return FALSE;
    }

    auto_jid Jid* jidp = jid_create(jid);
    if (jidp && jidp->domainpart) {
        muc_confserver_add(jidp->domainpart);
    }

    if (g_hash_table_contains(bookmarks, jid)) {
        return FALSE;
    }

    Bookmark* bookmark = g_new0(Bookmark, 1);
    bookmark->barejid = g_strdup(jid);
    if (nick) {
        bookmark->nick = g_strdup(nick);
    } else {
        bookmark->nick = NULL;
    }
    if (password) {
        bookmark->password = g_strdup(password);
    } else {
        bookmark->password = NULL;
    }
    if (name) {
        bookmark->name = g_strdup(name);
    } else {
        bookmark->name = NULL;
    }
    bookmark->ext_gajim_minimize = 0;

    if (g_strcmp0(autojoin_str, "on") == 0) {
        bookmark->autojoin = TRUE;
    } else {
        bookmark->autojoin = FALSE;
    }

    g_hash_table_insert(bookmarks, g_strdup(jid), bookmark);
    autocomplete_add(bookmark_ac, jid);

    _send_bookmarks();

    return TRUE;
}

gboolean
bookmark_update(const char* jid, const char* nick, const char* password, const char* autojoin_str, const char* name)
{
    assert(jid != NULL);

    Bookmark* bookmark = g_hash_table_lookup(bookmarks, jid);
    if (!bookmark) {
        return FALSE;
    }

    if (nick) {
        g_set_str(&bookmark->nick, nick);
    }
    if (password) {
        g_set_str(&bookmark->password, password);
    }
    if (name) {
        g_set_str(&bookmark->name, name);
    }
    if (autojoin_str) {
        if (g_strcmp0(autojoin_str, "on") == 0) {
            bookmark->autojoin = TRUE;
        } else if (g_strcmp0(autojoin_str, "off") == 0) {
            bookmark->autojoin = FALSE;
        }
    }

    _send_bookmarks();
    return TRUE;
}

gboolean
bookmark_join(const char* jid)
{
    assert(jid != NULL);

    Bookmark* bookmark = g_hash_table_lookup(bookmarks, jid);
    if (!bookmark) {
        return FALSE;
    }

    ProfAccount* account = accounts_get_account(session_get_account_name());
    if (!muc_active(bookmark->barejid)) {
        char* nick = bookmark->nick;
        if (!nick) {
            nick = account->muc_nick;
        }
        presence_join_room(bookmark->barejid, nick, bookmark->password);
        muc_join(bookmark->barejid, nick, bookmark->password, FALSE);
        iq_room_affiliation_list(bookmark->barejid, "member", FALSE);
        iq_room_affiliation_list(bookmark->barejid, "admin", FALSE);
        iq_room_affiliation_list(bookmark->barejid, "owner", FALSE);
        account_free(account);
    } else if (muc_roster_complete(bookmark->barejid)) {
        ui_room_join(bookmark->barejid, TRUE);
        account_free(account);
    }

    return TRUE;
}

gboolean
bookmark_remove(const char* jid)
{
    assert(jid != NULL);

    Bookmark* bookmark = g_hash_table_lookup(bookmarks, jid);
    if (!bookmark) {
        return FALSE;
    }

    g_hash_table_remove(bookmarks, jid);
    autocomplete_remove(bookmark_ac, jid);

    _send_bookmarks();

    return TRUE;
}

Bookmark*
bookmark_get_by_jid(const char* jid)
{
    Bookmark* bookmark = g_hash_table_lookup(bookmarks, jid);
    return bookmark;
}

GList*
bookmark_get_list(void)
{
    return g_hash_table_get_values(bookmarks);
}

char*
bookmark_find(const char* const search_str, gboolean previous, void* context)
{
    return autocomplete_complete(bookmark_ac, search_str, TRUE, previous);
}

void
bookmark_autocomplete_reset(void)
{
    if (bookmark_ac) {
        autocomplete_reset(bookmark_ac);
    }
}

gboolean
bookmark_exists(const char* const room)
{
    return g_hash_table_contains(bookmarks, room);
}

static int
_bookmark_result_id_handler(xmpp_stanza_t* const stanza, void* const userdata)
{
    const char* name = xmpp_stanza_get_name(stanza);
    if (!name || strcmp(name, STANZA_NAME_IQ) != 0) {
        return 0;
    }

    xmpp_stanza_t* query = xmpp_stanza_get_child_by_name(stanza, STANZA_NAME_QUERY);
    if (!query) {
        return 0;
    }
    xmpp_stanza_t* storage = xmpp_stanza_get_child_by_name(query, STANZA_NAME_STORAGE);
    if (!storage) {
        return 0;
    }

    if (bookmark_ac == NULL) {
        bookmark_ac = autocomplete_new();
    }

    xmpp_stanza_t* child = xmpp_stanza_get_children(storage);
    while (child) {
        name = xmpp_stanza_get_name(child);
        if (!name || strcmp(name, STANZA_NAME_CONFERENCE) != 0) {
            child = xmpp_stanza_get_next(child);
            continue;
        }
        const char* barejid = xmpp_stanza_get_attribute(child, STANZA_ATTR_JID);
        if (!barejid || !jid_is_valid_user_jid(barejid) || g_utf8_strchr(barejid, -1, '/') != NULL) {
            log_warning("Ignoring bookmark with invalid room JID: %s", barejid ? barejid : "(null)");
            child = xmpp_stanza_get_next(child);
            continue;
        }

        log_debug("Handle bookmark for %s", barejid);

        const char* room_name = xmpp_stanza_get_attribute(child, "name");

        char* nick = NULL;
        xmpp_stanza_t* nick_st = xmpp_stanza_get_child_by_name(child, "nick");
        if (nick_st) {
            nick = stanza_text_strdup(nick_st);
        }

        char* password = NULL;
        xmpp_stanza_t* password_st = xmpp_stanza_get_child_by_name(child, "password");
        if (password_st) {
            password = stanza_text_strdup(password_st);
        }

        const char* autojoin = xmpp_stanza_get_attribute(child, "autojoin");
        gboolean autojoin_val = FALSE;
        if (autojoin && (strcmp(autojoin, "1") == 0 || strcmp(autojoin, "true") == 0)) {
            autojoin_val = TRUE;
        }

        // we save minimize, which is not standard, so that we don't remove it if it was set by gajim
        int minimize = 0;
        xmpp_stanza_t* minimize_st = xmpp_stanza_get_child_by_name_and_ns(child, STANZA_NAME_MINIMIZE, STANZA_NS_EXT_GAJIM_BOOKMARKS);
        if (minimize_st) {
            auto_char char* min_str = xmpp_stanza_get_text(minimize_st);
            if (strcmp(min_str, "true") == 0) {
                minimize = 1;
            } else if (strcmp(min_str, "false") == 0) {
                minimize = 2;
            }
        }

        autocomplete_add(bookmark_ac, barejid);
        Bookmark* bookmark = g_new0(Bookmark, 1);
        bookmark->barejid = g_strdup(barejid);
        bookmark->nick = nick;
        bookmark->password = password;
        bookmark->name = room_name ? g_strdup(room_name) : NULL;
        bookmark->autojoin = autojoin_val;
        bookmark->ext_gajim_minimize = minimize;
        g_hash_table_insert(bookmarks, g_strdup(barejid), bookmark);

        if (autojoin_val) {
            sv_ev_bookmark_autojoin(bookmark);
        }

        auto_jid Jid* jidp = jid_create(barejid);
        if (jidp && jidp->domainpart) {
            muc_confserver_add(jidp->domainpart);
        }

        child = xmpp_stanza_get_next(child);
    }

    return 0;
}

static void
_bookmark_destroy(Bookmark* bookmark)
{
    if (bookmark) {
        g_free(bookmark->barejid);
        g_free(bookmark->nick);
        g_free(bookmark->password);
        g_free(bookmark->name);
        g_free(bookmark);
    }
}

static void
_send_bookmarks(void)
{
    xmpp_ctx_t* ctx = connection_get_ctx();

    auto_gchar gchar* id = connection_create_stanza_id();
    xmpp_stanza_t* iq = xmpp_iq_new(ctx, STANZA_TYPE_SET, id);

    xmpp_stanza_t* query = xmpp_stanza_new(ctx);
    xmpp_stanza_set_name(query, STANZA_NAME_QUERY);
    xmpp_stanza_set_ns(query, "jabber:iq:private");

    xmpp_stanza_t* storage = xmpp_stanza_new(ctx);
    xmpp_stanza_set_name(storage, STANZA_NAME_STORAGE);
    xmpp_stanza_set_ns(storage, "storage:bookmarks");

    GList* bookmark_list = g_hash_table_get_values(bookmarks);
    GList* curr = bookmark_list;
    while (curr) {
        Bookmark* bookmark = curr->data;
        xmpp_stanza_t* conference = xmpp_stanza_new(ctx);
        xmpp_stanza_set_name(conference, STANZA_NAME_CONFERENCE);
        xmpp_stanza_set_attribute(conference, STANZA_ATTR_JID, bookmark->barejid);

        if (bookmark->name) {
            // use specified bookmark name
            xmpp_stanza_set_attribute(conference, STANZA_ATTR_NAME, bookmark->name);
        } else {
            // use localpart of JID by if no name is specified
            auto_jid Jid* jidp = jid_create(bookmark->barejid);
            if (jidp && jidp->localpart) {
                xmpp_stanza_set_attribute(conference, STANZA_ATTR_NAME, jidp->localpart);
            }
        }

        if (bookmark->autojoin) {
            xmpp_stanza_set_attribute(conference, STANZA_ATTR_AUTOJOIN, "true");
        } else {
            xmpp_stanza_set_attribute(conference, STANZA_ATTR_AUTOJOIN, "false");
        }

        if (bookmark->nick) {
            xmpp_stanza_t* nick_st = xmpp_stanza_new(ctx);
            xmpp_stanza_set_name(nick_st, STANZA_NAME_NICK);
            xmpp_stanza_t* nick_text = xmpp_stanza_new(ctx);
            xmpp_stanza_set_text(nick_text, bookmark->nick);
            xmpp_stanza_add_child(nick_st, nick_text);
            xmpp_stanza_add_child(conference, nick_st);

            xmpp_stanza_release(nick_text);
            xmpp_stanza_release(nick_st);
        }

        if (bookmark->password) {
            xmpp_stanza_t* password_st = xmpp_stanza_new(ctx);
            xmpp_stanza_set_name(password_st, STANZA_NAME_PASSWORD);
            xmpp_stanza_t* password_text = xmpp_stanza_new(ctx);
            xmpp_stanza_set_text(password_text, bookmark->password);
            xmpp_stanza_add_child(password_st, password_text);
            xmpp_stanza_add_child(conference, password_st);

            xmpp_stanza_release(password_text);
            xmpp_stanza_release(password_st);
        }

        if (bookmark->ext_gajim_minimize == 1 || bookmark->ext_gajim_minimize == 2) {
            xmpp_stanza_t* minimize_st = xmpp_stanza_new(ctx);
            xmpp_stanza_set_name(minimize_st, STANZA_NAME_MINIMIZE);
            xmpp_stanza_set_ns(minimize_st, STANZA_NS_EXT_GAJIM_BOOKMARKS);

            xmpp_stanza_t* minimize_text = xmpp_stanza_new(ctx);
            if (bookmark->ext_gajim_minimize == 1) {
                xmpp_stanza_set_text(minimize_text, "true");
            } else {
                xmpp_stanza_set_text(minimize_text, "false");
            }

            xmpp_stanza_add_child(minimize_st, minimize_text);
            xmpp_stanza_add_child(conference, minimize_st);

            xmpp_stanza_release(minimize_text);
            xmpp_stanza_release(minimize_st);
        }

        xmpp_stanza_add_child(storage, conference);
        xmpp_stanza_release(conference);

        curr = curr->next;
    }

    g_list_free(bookmark_list);

    xmpp_stanza_add_child(query, storage);
    xmpp_stanza_add_child(iq, query);
    xmpp_stanza_release(storage);
    xmpp_stanza_release(query);

    iq_send_stanza(iq);
    xmpp_stanza_release(iq);
}
