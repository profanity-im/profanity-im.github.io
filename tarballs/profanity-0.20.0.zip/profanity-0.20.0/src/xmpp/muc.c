/*
 * muc.c
 * vim: expandtab:ts=4:sts=4:sw=4
 *
 * Copyright (C) 2012 - 2019 James Booth <boothj5@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later WITH OpenSSL-exception
 */

#include "config.h"

#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include <glib.h>

#include "common.h"
#include "log.h"
#include "tools/autocomplete.h"
#include "ui/ui.h"
#include "ui/window_list.h"
#include "xmpp/jid.h"
#include "xmpp/muc.h"
#include "xmpp/contact.h"

#ifdef HAVE_OMEMO
#include "omemo/omemo.h"
#endif

typedef struct _muc_room_t
{
    char* room; // e.g. test@conference.server
    char* nick; // e.g. Some User
    muc_role_t role;
    muc_affiliation_t affiliation;
    char* password;
    char* subject;
    char* autocomplete_prefix;
    gboolean pending_config;
    GList* pending_broadcasts;
    gboolean autojoin;
    gboolean pending_nick_change;
    GHashTable* roster;
    GHashTable* members;
    Autocomplete nick_ac;
    Autocomplete jid_ac;
    GHashTable* nick_changes;
    gboolean roster_received;
    muc_member_type_t member_type;
    muc_anonymity_type_t anonymity_type;
    gint64 last_activity;
    gint64 ping_sent_time;
    gboolean supports_mam;
} ChatRoom;

GHashTable* rooms = NULL;
GHashTable* invite_passwords = NULL;
Autocomplete invite_ac = NULL;
Autocomplete confservers_ac = NULL;

static void _free_room(ChatRoom* room);
static gint _compare_occupants(Occupant* a, Occupant* b);
static muc_role_t _role_from_string(const gchar* const role);
static muc_affiliation_t _affiliation_from_string(const gchar* const affiliation);
static char* _role_to_string(muc_role_t role);
static char* _affiliation_to_string(muc_affiliation_t affiliation);
static Occupant* _muc_occupant_new(const gchar* const nick, const gchar* const jid, muc_role_t role,
                                   muc_affiliation_t affiliation, resource_presence_t presence, const gchar* const status);
static void _occupant_free(Occupant* occupant);

static void
_muc_close(void)
{
    g_clear_pointer(&invite_passwords, g_hash_table_destroy);
    g_clear_pointer(&rooms, g_hash_table_destroy);
    g_clear_pointer(&confservers_ac, autocomplete_free);
    g_clear_pointer(&invite_ac, autocomplete_free);
}

void
muc_init(void)
{
    prof_add_shutdown_routine(_muc_close);
    invite_ac = autocomplete_new();
    confservers_ac = autocomplete_new();
    rooms = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, (GDestroyNotify)_free_room);
    invite_passwords = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, g_free);
}

void
muc_confserver_add(const gchar* const server)
{
    autocomplete_add(confservers_ac, server);
}

void
muc_invites_add(const gchar* const room, const gchar* const password)
{
    autocomplete_add(invite_ac, room);
    if (password) {
        g_hash_table_replace(invite_passwords, g_strdup(room), g_strdup(password));
    }
}

void
muc_invites_remove(const gchar* const room)
{
    autocomplete_remove(invite_ac, room);
    g_hash_table_remove(invite_passwords, room);
}

gint
muc_invites_count(void)
{
    return autocomplete_length(invite_ac);
}

GList*
muc_invites(void)
{
    return autocomplete_create_list(invite_ac);
}

gchar*
muc_invite_password(const gchar* const room)
{
    return g_hash_table_lookup(invite_passwords, room);
}

gboolean
muc_invites_contain(const gchar* const room)
{
    GList* invites = autocomplete_create_list(invite_ac);
    GList* curr = invites;
    while (curr) {
        if (strcmp(curr->data, room) == 0) {
            g_list_free_full(invites, g_free);
            return TRUE;
        } else {
            curr = g_list_next(curr);
        }
    }
    g_list_free_full(invites, g_free);

    return FALSE;
}

void
muc_invites_reset_ac(void)
{
    autocomplete_reset(invite_ac);
}

void
muc_confserver_reset_ac(void)
{
    autocomplete_reset(confservers_ac);
}

gchar*
muc_invites_find(const gchar* const search_str, gboolean previous, void* context)
{
    return autocomplete_complete(invite_ac, search_str, TRUE, previous);
}

gchar*
muc_confserver_find(const gchar* const search_str, gboolean previous, void* context)
{
    return autocomplete_complete(confservers_ac, search_str, TRUE, previous);
}

void
muc_invites_clear(void)
{
    autocomplete_clear(invite_ac);
    if (invite_passwords) {
        g_hash_table_remove_all(invite_passwords);
    }
}

void
muc_confserver_clear(void)
{
    autocomplete_clear(confservers_ac);
}

void
muc_join(const gchar* const room, const gchar* const nick, const gchar* const password, gboolean autojoin)
{
    if (room == NULL || !jid_is_valid_user_jid(room) || g_utf8_strchr(room, -1, '/') != NULL) {
        log_warning("muc: invalid room JID: %s", room ? room : "(null)");
        return;
    }

    ChatRoom* new_room = g_new0(ChatRoom, 1);
    new_room->room = g_strdup(room);
    new_room->nick = g_strdup(nick);
    new_room->role = MUC_ROLE_NONE;
    new_room->affiliation = MUC_AFFILIATION_NONE;
    new_room->autocomplete_prefix = NULL;
    if (password) {
        new_room->password = g_strdup(password);
    } else {
        new_room->password = NULL;
    }
    new_room->subject = NULL;
    new_room->pending_broadcasts = NULL;
    new_room->pending_config = FALSE;
    new_room->roster = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, (GDestroyNotify)_occupant_free);
    new_room->members = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, NULL);
    new_room->nick_ac = autocomplete_new();
    new_room->jid_ac = autocomplete_new();
    new_room->nick_changes = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, g_free);
    new_room->roster_received = FALSE;
    new_room->pending_nick_change = FALSE;
    new_room->autojoin = autojoin;
    new_room->member_type = MUC_MEMBER_TYPE_UNKNOWN;
    new_room->anonymity_type = MUC_ANONYMITY_TYPE_UNKNOWN;
    new_room->last_activity = g_get_monotonic_time() / G_TIME_SPAN_SECOND;
    new_room->ping_sent_time = 0;

    g_hash_table_insert(rooms, g_strdup(room), new_room);
}

void
muc_leave(const gchar* const room)
{
    g_hash_table_remove(rooms, room);
}

void
muc_update_activity(const gchar* const room)
{
    if (room == NULL) {
        return;
    }
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        chat_room->last_activity = g_get_monotonic_time() / G_TIME_SPAN_SECOND;
    }
}

gint64
muc_last_activity(const gchar* const room)
{
    if (room == NULL) {
        return 0;
    }
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->last_activity;
    } else {
        return 0;
    }
}

void
muc_set_ping_sent_time(const gchar* const room, gint64 time)
{
    if (room == NULL) {
        return;
    }
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        chat_room->ping_sent_time = time;
    }
}

gint64
muc_ping_sent_time(const gchar* const room)
{
    if (room == NULL) {
        return 0;
    }
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->ping_sent_time;
    } else {
        return 0;
    }
}

gboolean
muc_requires_config(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->pending_config;
    } else {
        return FALSE;
    }
}

void
muc_set_requires_config(const gchar* const room, gboolean val)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        chat_room->pending_config = val;
    }
}

void
muc_set_features(const gchar* const room, GSList* features)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room && features) {
        if (g_slist_find_custom(features, "muc_membersonly", (GCompareFunc)g_strcmp0)) {
            chat_room->member_type = MUC_MEMBER_TYPE_MEMBERS_ONLY;
        } else {
            chat_room->member_type = MUC_MEMBER_TYPE_PUBLIC;
        }
        if (g_slist_find_custom(features, "muc_nonanonymous", (GCompareFunc)g_strcmp0)) {
            chat_room->anonymity_type = MUC_ANONYMITY_TYPE_NONANONYMOUS;
        } else if (g_slist_find_custom(features, "muc_semianonymous", (GCompareFunc)g_strcmp0)) {
            chat_room->anonymity_type = MUC_ANONYMITY_TYPE_SEMIANONYMOUS;
        } else {
            chat_room->anonymity_type = MUC_ANONYMITY_TYPE_UNKNOWN;
        }
        if (g_slist_find_custom(features, "urn:xmpp:mam:2", (GCompareFunc)g_strcmp0)) {
            chat_room->supports_mam = TRUE;
        } else {
            chat_room->supports_mam = FALSE;
        }
    }
}

gboolean
muc_supports_mam(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->supports_mam;
    } else {
        return FALSE;
    }
}

/*
 * Returns TRUE if the user is currently in the room
 */
gboolean
muc_active(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    return (chat_room != NULL);
}

gboolean
muc_autojoin(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->autojoin;
    } else {
        return FALSE;
    }
}

void
muc_set_subject(const gchar* const room, const gchar* const subject)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        g_free(chat_room->subject);
        if (subject) {
            chat_room->subject = g_strdup(subject);
        } else {
            chat_room->subject = NULL;
        }
    }
}

gchar*
muc_subject(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->subject;
    } else {
        return NULL;
    }
}

void
muc_pending_broadcasts_add(const gchar* const room, const gchar* const message)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        chat_room->pending_broadcasts = g_list_append(chat_room->pending_broadcasts, g_strdup(message));
    }
}

GList*
muc_pending_broadcasts(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->pending_broadcasts;
    } else {
        return NULL;
    }
}

gchar*
muc_old_nick(const gchar* const room, const gchar* const new_nick)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room && chat_room->pending_nick_change) {
        return g_hash_table_lookup(chat_room->nick_changes, new_nick);
    } else {
        return NULL;
    }
}

/*
 * Flag that the user has sent a nick change to the service
 * and is awaiting the response
 */
void
muc_nick_change_start(const gchar* const room, const gchar* const new_nick)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        chat_room->pending_nick_change = TRUE;
        g_hash_table_insert(chat_room->nick_changes, g_strdup(new_nick), g_strdup(chat_room->nick));
    }
}

/*
 * Returns TRUE if the room is awaiting the result of a
 * nick change
 */
gboolean
muc_nick_change_pending(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->pending_nick_change;
    } else {
        return FALSE;
    }
}

/*
 * Change the current nick name for the room, call once
 * the service has responded
 */
void
muc_nick_change_complete(const gchar* const room, const gchar* const nick)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        g_hash_table_remove(chat_room->roster, chat_room->nick);
        autocomplete_remove(chat_room->nick_ac, chat_room->nick);
        g_set_str(&chat_room->nick, nick);
        chat_room->pending_nick_change = FALSE;
        g_hash_table_remove(chat_room->nick_changes, nick);
    }
}

/*
 * Return a list of room names
 * The contents of the list are owned by the chat room and should not be
 * modified or freed.
 */
GList*
muc_rooms(void)
{
    return g_hash_table_get_keys(rooms);
}

/*
 * Return current users nickname for the specified room
 * The nickname is owned by the chat room and should not be modified or freed
 */
const gchar*
muc_nick(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->nick;
    } else {
        return NULL;
    }
}

/*
 * Return password for the specified room
 * The password is owned by the chat room and should not be modified or freed
 */
gchar*
muc_password(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->password;
    } else {
        return NULL;
    }
}

/*
 * Returns TRUE if the specified nick exists in the room's roster
 */
gboolean
muc_roster_contains_nick(const gchar* const room, const gchar* const nick)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        Occupant* occupant = g_hash_table_lookup(chat_room->roster, nick);
        return (occupant != NULL);
    } else {
        return FALSE;
    }
}

/*
 * Add a new chat room member to the room's roster
 */
gboolean
muc_roster_add(const gchar* const room, const gchar* const nick, const gchar* const jid, const gchar* const role,
               const gchar* const affiliation, const gchar* const show, const gchar* const status)
{
    if (!room || !nick) {
        return FALSE;
    }

    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    gboolean updated = FALSE;
    resource_presence_t new_presence = resource_presence_from_string(show);

    if (chat_room) {
        Occupant* old = g_hash_table_lookup(chat_room->roster, nick);

        if (!old) {
            updated = TRUE;
            autocomplete_add(chat_room->nick_ac, nick);
        } else if (old->presence != new_presence || (g_strcmp0(old->status, status) != 0)) {
            updated = TRUE;
        }

        resource_presence_t presence = resource_presence_from_string(show);
        muc_role_t role_t = _role_from_string(role);
        muc_affiliation_t affiliation_t = _affiliation_from_string(affiliation);
        Occupant* occupant = _muc_occupant_new(nick, jid, role_t, affiliation_t, presence, status);
        g_hash_table_replace(chat_room->roster, g_strdup(nick), occupant);

        if (jid) {
            auto_jid Jid* jidp = jid_create(jid);
            if (jidp->barejid) {
                autocomplete_add(chat_room->jid_ac, jidp->barejid);
            }
        }
    }

    return updated;
}

/*
 * Remove a room member from the room's roster
 */
void
muc_roster_remove(const gchar* const room, const gchar* const nick)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        g_hash_table_remove(chat_room->roster, nick);
        autocomplete_remove(chat_room->nick_ac, nick);
    }
}

Occupant*
muc_roster_item(const gchar* const room, const gchar* const nick)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        Occupant* occupant = g_hash_table_lookup(chat_room->roster, nick);
        return occupant;
    } else {
        return NULL;
    }
}

/*
 * Return a list of PContacts representing the room members in the room's roster
 */
GList*
muc_roster(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        GList* result = NULL;
        GList* occupants = g_hash_table_get_values(chat_room->roster);

        GList* curr = occupants;
        while (curr) {
            result = g_list_insert_sorted(result, curr->data, (GCompareFunc)_compare_occupants);
            curr = g_list_next(curr);
        }

        g_list_free(occupants);

        return result;
    } else {
        return NULL;
    }
}

/*
 * Return a Autocomplete representing the room member's in the roster
 */
Autocomplete
muc_roster_ac(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->nick_ac;
    } else {
        return NULL;
    }
}

Autocomplete
muc_roster_jid_ac(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->jid_ac;
    } else {
        return NULL;
    }
}

/*
 * Set to TRUE when the rooms roster has been fully received
 */
void
muc_roster_set_complete(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        chat_room->roster_received = TRUE;
    }
}

/*
 * Returns TRUE id the rooms roster has been fully received
 */
gboolean
muc_roster_complete(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->roster_received;
    } else {
        return FALSE;
    }
}

gboolean
muc_occupant_available(Occupant* occupant)
{
    return (occupant->presence == RESOURCE_ONLINE || occupant->presence == RESOURCE_CHAT);
}

const gchar*
muc_occupant_affiliation_str(Occupant* occupant)
{
    return _affiliation_to_string(occupant->affiliation);
}

const gchar*
muc_occupant_role_str(Occupant* occupant)
{
    return _role_to_string(occupant->role);
}

GSList*
muc_occupants_by_role(const gchar* const room, muc_role_t role)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        GSList* result = NULL;
        GHashTableIter iter;
        gpointer key;
        gpointer value;

        g_hash_table_iter_init(&iter, chat_room->roster);
        while (g_hash_table_iter_next(&iter, &key, &value)) {
            Occupant* occupant = (Occupant*)value;
            if (occupant->role == role) {
                result = g_slist_insert_sorted(result, value, (GCompareFunc)_compare_occupants);
            }
        }
        return result;
    } else {
        return NULL;
    }
}

GSList*
muc_occupants_by_affiliation(const gchar* const room, muc_affiliation_t affiliation)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        GSList* result = NULL;
        GHashTableIter iter;
        gpointer key;
        gpointer value;

        g_hash_table_iter_init(&iter, chat_room->roster);
        while (g_hash_table_iter_next(&iter, &key, &value)) {
            Occupant* occupant = (Occupant*)value;
            if (occupant->affiliation == affiliation) {
                result = g_slist_insert_sorted(result, value, (GCompareFunc)_compare_occupants);
            }
        }
        return result;
    } else {
        return NULL;
    }
}

/*
 * Remove the old_nick from the roster, and flag that a pending nickname change
 * is in progress
 */
void
muc_occupant_nick_change_start(const gchar* const room, const gchar* const new_nick, const gchar* const old_nick)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        g_hash_table_insert(chat_room->nick_changes, g_strdup(new_nick), g_strdup(old_nick));
        muc_roster_remove(room, old_nick);
    }
}

/*
 * Complete the pending nick name change for a contact in the room's roster
 * The new nick name will be added to the roster
 * The old nick name will be returned in a new string which must be freed by
 * the caller
 */
gchar*
muc_roster_nick_change_complete(const gchar* const room, const gchar* const nick)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        char* old_nick = g_hash_table_lookup(chat_room->nick_changes, nick);
        if (old_nick) {
            char* old_nick_cpy = g_strdup(old_nick);
            g_hash_table_remove(chat_room->nick_changes, nick);

            return old_nick_cpy;
        }
    }

    return NULL;
}

gchar*
muc_autocomplete(ProfWin* window, const gchar* const input, gboolean previous)
{
    if (window->type != WIN_MUC) {
        return NULL;
    }

    ProfMucWin* mucwin = (ProfMucWin*)window;
    ChatRoom* chat_room = g_hash_table_lookup(rooms, mucwin->roomjid);
    if (chat_room == NULL || chat_room->nick_ac == NULL) {
        return NULL;
    }

    const char* search_str = NULL;

    gchar* last_space = g_strrstr(input, " ");
    if (!last_space) {
        search_str = input;
        if (!chat_room->autocomplete_prefix) {
            chat_room->autocomplete_prefix = g_strdup("");
        }
    } else {
        search_str = last_space + 1;
        if (!chat_room->autocomplete_prefix) {
            chat_room->autocomplete_prefix = g_strndup(input, search_str - input);
        }
    }

    auto_gchar gchar* result = autocomplete_complete(chat_room->nick_ac, search_str, FALSE, previous);
    if (result == NULL) {
        return NULL;
    }

    GString* replace_with = g_string_new(chat_room->autocomplete_prefix);
    g_string_append(replace_with, result);

    if (strlen(chat_room->autocomplete_prefix) == 0) {
        g_string_append(replace_with, ": ");
    }
    return g_string_free_and_steal(replace_with);
}

void
muc_jid_autocomplete_reset(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        if (chat_room->jid_ac) {
            autocomplete_reset(chat_room->jid_ac);
        }
    }
}

void
muc_jid_autocomplete_add_all(const gchar* const room, GSList* jids)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        if (chat_room->jid_ac) {
            GSList* curr_jid = jids;
            while (curr_jid) {
                const char* jid = curr_jid->data;
                auto_jid Jid* jidp = jid_create(jid);
                if (jidp) {
                    if (jidp->barejid) {
                        autocomplete_add(chat_room->jid_ac, jidp->barejid);
                    }
                }
                curr_jid = g_slist_next(curr_jid);
            }
        }
    }
}

void
muc_autocomplete_reset(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        if (chat_room->nick_ac) {
            autocomplete_reset(chat_room->nick_ac);
        }

        g_clear_pointer(&chat_room->autocomplete_prefix, g_free);
    }
}

gchar*
muc_role_str(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return _role_to_string(chat_room->role);
    } else {
        return "none";
    }
}

void
muc_set_role(const gchar* const room, const gchar* const role)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        chat_room->role = _role_from_string(role);
    }
}

gchar*
muc_affiliation_str(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return _affiliation_to_string(chat_room->affiliation);
    } else {
        return "none";
    }
}

void
muc_set_affiliation(const gchar* const room, const gchar* const affiliation)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        chat_room->affiliation = _affiliation_from_string(affiliation);
    }
}

muc_member_type_t
muc_member_type(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->member_type;
    } else {
        return MUC_MEMBER_TYPE_UNKNOWN;
    }
}

muc_anonymity_type_t
muc_anonymity_type(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return chat_room->anonymity_type;
    } else {
        return MUC_ANONYMITY_TYPE_UNKNOWN;
    }
}

/*
 * Return the list of jid affiliated as member in the room
 */
GList*
muc_members(const gchar* const room)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        return g_hash_table_get_keys(chat_room->members);
    } else {
        return NULL;
    }
}

void
muc_members_add(const gchar* const room, const gchar* const jid)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        if (g_hash_table_insert(chat_room->members, g_strdup(jid), NULL)) {
#ifdef HAVE_OMEMO
            if (chat_room->anonymity_type == MUC_ANONYMITY_TYPE_NONANONYMOUS) {
                if (!equals_our_barejid(jid)) {
                    ProfMucWin* mucwin = wins_get_muc(room);
                    if (mucwin && mucwin->is_omemo) {
                        omemo_start_session(jid);
                    }
                }
            }
#endif
        }
    }
}

void
muc_members_remove(const gchar* const room, const gchar* const jid)
{
    ChatRoom* chat_room = g_hash_table_lookup(rooms, room);
    if (chat_room) {
        g_hash_table_remove(chat_room->members, jid);
    }
}

void
muc_members_update(const gchar* const room, const gchar* const jid, const gchar* const affiliation)
{
    if (strcmp(affiliation, "outcast") == 0 || strcmp(affiliation, "none") == 0) {
        muc_members_remove(room, jid);
    } else if (strcmp(affiliation, "member") == 0 || strcmp(affiliation, "admin") == 0 || strcmp(affiliation, "owner") == 0) {
        muc_members_add(room, jid);
    }
}

static void
_free_room(ChatRoom* room)
{
    if (room) {
        g_free(room->room);
        g_free(room->nick);
        g_free(room->subject);
        g_free(room->password);
        g_free(room->autocomplete_prefix);
        if (room->roster) {
            g_hash_table_destroy(room->roster);
        }
        if (room->members) {
            g_hash_table_destroy(room->members);
        }
        autocomplete_free(room->nick_ac);
        autocomplete_free(room->jid_ac);
        if (room->nick_changes) {
            g_hash_table_destroy(room->nick_changes);
        }
        if (room->pending_broadcasts) {
            g_list_free_full(room->pending_broadcasts, g_free);
        }
        g_free(room);
    }
}

static gint
_compare_occupants(Occupant* a, Occupant* b)
{
    const char* utf8_str_a = a->nick_collate_key;
    const char* utf8_str_b = b->nick_collate_key;

    gint result = g_strcmp0(utf8_str_a, utf8_str_b);

    return result;
}

static muc_role_t
_role_from_string(const gchar* const role)
{
    if (role) {
        if (g_strcmp0(role, "visitor") == 0) {
            return MUC_ROLE_VISITOR;
        } else if (g_strcmp0(role, "participant") == 0) {
            return MUC_ROLE_PARTICIPANT;
        } else if (g_strcmp0(role, "moderator") == 0) {
            return MUC_ROLE_MODERATOR;
        } else {
            return MUC_ROLE_NONE;
        }
    } else {
        return MUC_ROLE_NONE;
    }
}

static char*
_role_to_string(muc_role_t role)
{
    char* result = NULL;

    switch (role) {
    case MUC_ROLE_NONE:
        result = "none";
        break;
    case MUC_ROLE_VISITOR:
        result = "visitor";
        break;
    case MUC_ROLE_PARTICIPANT:
        result = "participant";
        break;
    case MUC_ROLE_MODERATOR:
        result = "moderator";
        break;
    default:
        result = "none";
        break;
    }

    return result;
}

static muc_affiliation_t
_affiliation_from_string(const gchar* const affiliation)
{
    if (affiliation) {
        if (g_strcmp0(affiliation, "outcast") == 0) {
            return MUC_AFFILIATION_OUTCAST;
        } else if (g_strcmp0(affiliation, "member") == 0) {
            return MUC_AFFILIATION_MEMBER;
        } else if (g_strcmp0(affiliation, "admin") == 0) {
            return MUC_AFFILIATION_ADMIN;
        } else if (g_strcmp0(affiliation, "owner") == 0) {
            return MUC_AFFILIATION_OWNER;
        } else {
            return MUC_AFFILIATION_NONE;
        }
    } else {
        return MUC_AFFILIATION_NONE;
    }
}

static char*
_affiliation_to_string(muc_affiliation_t affiliation)
{
    char* result = NULL;

    switch (affiliation) {
    case MUC_AFFILIATION_NONE:
        result = "none";
        break;
    case MUC_AFFILIATION_OUTCAST:
        result = "outcast";
        break;
    case MUC_AFFILIATION_MEMBER:
        result = "member";
        break;
    case MUC_AFFILIATION_ADMIN:
        result = "admin";
        break;
    case MUC_AFFILIATION_OWNER:
        result = "owner";
        break;
    default:
        result = "none";
        break;
    }

    return result;
}

static Occupant*
_muc_occupant_new(const gchar* const nick, const gchar* const jid, muc_role_t role, muc_affiliation_t affiliation,
                  resource_presence_t presence, const gchar* const status)
{
    Occupant* occupant = g_new0(Occupant, 1);

    occupant->nick = g_strdup(nick);
    occupant->nick_collate_key = g_utf8_collate_key(occupant->nick, -1);

    if (jid) {
        occupant->jid = g_strdup(jid);
    } else {
        occupant->jid = NULL;
    }

    occupant->presence = presence;

    if (status) {
        occupant->status = g_strdup(status);
    } else {
        occupant->status = NULL;
    }

    occupant->role = role;
    occupant->affiliation = affiliation;

    return occupant;
}

static void
_occupant_free(Occupant* occupant)
{
    if (occupant) {
        g_free(occupant->nick);
        g_free(occupant->nick_collate_key);
        g_free(occupant->jid);
        g_free(occupant->status);
        g_free(occupant);
    }
}
