void cmd_win_shows_message_when_win_doesnt_exist(void **state);
void cmd_win_switches_to_given_win_when_exists(void **state);
