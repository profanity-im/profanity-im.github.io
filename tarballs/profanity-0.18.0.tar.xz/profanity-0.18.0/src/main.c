/*
 * main.c
 * vim: expandtab:ts=4:sts=4:sw=4
 *
 * Copyright (C) 2012 - 2019 James Booth <boothj5@gmail.com>
 * Copyright (C) 2019 - 2026 Michael Vetter <jubalh@iodoru.org>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later WITH OpenSSL-exception
 */

#include "config.h"

#include <string.h>
#include <glib.h>

#ifdef HAVE_LIBOTR
#include "otr/otr.h"
#endif

#ifdef HAVE_LIBGPGME
#include "pgp/gpg.h"
#endif

#ifdef HAVE_PYTHON
#include "plugins/python_plugins.h"
#endif

#include "profanity.h"
#include "common.h"
#include "command/cmd_defs.h"

int
main(int argc, char** argv)
{
    gboolean version = FALSE;
    auto_gchar gchar* log = NULL;
    auto_gchar gchar* log_file = NULL;
    auto_gchar gchar* account_name = NULL;
    auto_gchar gchar* config_file = NULL;
    auto_gchar gchar* theme_name = NULL;
    auto_gcharv gchar** commands = NULL;

    if (argc == 2 && g_strcmp0(PACKAGE_STATUS, "development") == 0) {
        if (g_strcmp0(argv[1], "docgen") == 0) {
            command_docgen();
            return 0;
        } else if (g_strcmp0(argv[1], "mangen") == 0) {
            command_mangen();
            return 0;
        }
    }

    GOptionEntry entries[] = {
        { "version", 'v', 0, G_OPTION_ARG_NONE, &version, "Show version information", NULL },
        { "account", 'a', 0, G_OPTION_ARG_STRING, &account_name, "Auto connect to an account on startup", NULL },
        { "log", 'l', 0, G_OPTION_ARG_STRING, &log, "Set logging levels, DEBUG, INFO, WARN (default), ERROR", "LEVEL" },
        { "config", 'c', 0, G_OPTION_ARG_STRING, &config_file, "Use an alternative configuration file", NULL },
        { "logfile", 'f', 0, G_OPTION_ARG_STRING, &log_file, "Specify log file", NULL },
        { "theme", 't', 0, G_OPTION_ARG_STRING, &theme_name, "Specify theme name", NULL },
        { "cmd", 'r', 0, G_OPTION_ARG_STRING_ARRAY, &commands, "First commands to run", NULL },
        { NULL }
    };

    GError* error = NULL;
    GOptionContext* context;

    context = g_option_context_new(NULL);
    g_option_context_add_main_entries(context, entries, NULL);
    if (!g_option_context_parse(context, &argc, &argv, &error)) {
        g_print("%s\n", PROF_GERROR_MESSAGE(error));
        g_option_context_free(context);
        PROF_GERROR_FREE(error);
        return 1;
    }

    g_option_context_free(context);

    if (version == TRUE) {
        auto_gchar gchar* prof_version = prof_get_version();
        g_print("Profanity, version %s\n", prof_version);

        // lets use fixed email instead of PACKAGE_BUGREPORT
        g_print("Copyright (C) 2012 - 2019 James Booth <boothj5web@gmail.com>.\n");
        g_print("Copyright (C) 2019 - 2026 Michael Vetter <jubalh@iodoru.org>.\n");
        g_print("License GPLv3+: GNU GPL version 3 or later <https://www.gnu.org/licenses/gpl.html>\n");
        g_print("\n");
        g_print("This is free software; you are free to change and redistribute it.\n");
        g_print("There is NO WARRANTY, to the extent permitted by law.\n");
        g_print("\n");

        g_print("Build information:\n");

        g_print("XMPP library: libstrophe\n");

        if (is_notify_enabled()) {
            g_print("Desktop notification support: Enabled\n");
        } else {
            g_print("Desktop notification support: Disabled\n");
        }

#ifdef HAVE_LIBOTR
        char* otr_version = otr_libotr_version();
        g_print("OTR support: Enabled (libotr %s)\n", otr_version);
#else
        g_print("OTR support: Disabled\n");
#endif

#ifdef HAVE_LIBGPGME
        const char* pgp_version = p_gpg_libver();
        g_print("PGP support: Enabled (libgpgme %s)\n", pgp_version);
#else
        g_print("PGP support: Disabled\n");
#endif

#ifdef HAVE_OMEMO
        g_print("OMEMO support: Enabled\n");
#else
        g_print("OMEMO support: Disabled\n");
#endif

#ifdef HAVE_C
        g_print("C plugins: Enabled\n");
#else
        g_print("C plugins: Disabled\n");
#endif

#ifdef HAVE_PYTHON
        auto_gchar gchar* python_version = python_get_version_number();
        g_print("Python plugins: Enabled (%s)\n", python_version);
#else
        g_print("Python plugins: Disabled\n");
#endif

#ifdef HAVE_GTK
        g_print("GTK icons/clipboard: Enabled\n");
#else
        g_print("GTK icons/clipboard: Disabled\n");
#endif

#ifdef HAVE_PIXBUF
        g_print("GDK Pixbuf: Enabled\n");
#else
        g_print("GDK Pixbuf: Disabled\n");
#endif

        return 0;
    }

    /* Default logging WARN */
    prof_run(log ? log : "WARN", account_name, config_file, log_file, theme_name, commands);

    return 0;
}
