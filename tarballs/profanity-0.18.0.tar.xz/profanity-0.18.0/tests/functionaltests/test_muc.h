/*
 * test_muc.h
 *
 * Copyright (C) 2015 - 2018 James Booth <boothj5@gmail.com>
 * Copyright (C) 2026 - 2026 Michael Vetter <jubalh@iodoru.org>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
void sends_room_join(void** state);
void sends_room_join_with_nick(void** state);
void sends_room_join_with_password(void** state);
void sends_room_join_with_nick_and_password(void** state);
void shows_role_and_affiliation_on_join(void** state);
void shows_subject_on_join(void** state);
void shows_history_message(void** state);
void shows_occupant_join(void** state);
void shows_message(void** state);
void shows_me_message_from_occupant(void** state);
void shows_me_message_from_self(void** state);
void shows_all_messages_in_console_when_window_not_focussed(void** state);
void shows_first_message_in_console_when_window_not_focussed(void** state);
void shows_no_message_in_console_when_window_not_focussed(void** state);
