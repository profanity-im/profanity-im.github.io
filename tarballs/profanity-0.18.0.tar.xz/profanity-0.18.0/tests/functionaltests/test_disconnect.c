/*
 * test_disconnect.c
 *
 * Copyright (C) 2016 James Booth <boothj5@gmail.com>
 * Copyright (C) 2026 - 2026 Michael Vetter <jubalh@iodoru.org>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#include <glib.h>
#include "prof_cmocka.h"
#include <stdlib.h>
#include <string.h>

#include <stabber.h>

#include "proftest.h"

void
disconnect_ends_session(void** state)
{
    prof_connect();

    prof_input("/disconnect");
    assert_true(prof_output_exact("stabber@localhost logged out successfully."));

    prof_input("/roster");
    assert_true(prof_output_exact("You are not currently connected."));
}
