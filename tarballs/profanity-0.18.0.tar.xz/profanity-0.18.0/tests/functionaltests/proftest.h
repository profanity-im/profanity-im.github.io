/*
 * proftest.h
 *
 * Copyright (C) 2015 James Booth <boothj5@gmail.com>
 * Copyright (C) 2020 - 2026 Michael Vetter <jubalh@iodoru.org>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#ifndef __H_PROFTEST
#define __H_PROFTEST

#define XDG_CONFIG_HOME "./tests/functionaltests/files/xdg_config_home"
#define XDG_DATA_HOME   "./tests/functionaltests/files/xdg_data_home"

enum prof_expect_type {
    prof_expect_end = 0,
    prof_expect_exact,
    prof_expect_regexp
};

extern int prof_expect_timeout;
extern int prof_pid;

int init_prof_test(void** state);
int close_prof_test(void** state);

void prof_start(void);
void prof_connect(void);
void prof_connect_with_roster(const char* roster);
void prof_input(const char* input);
void prof_send_raw(const char* bytes);

int prof_output_exact(const char* text);
int prof_output_regex(const char* text);

void prof_timeout(int timeout);
void prof_timeout_reset(void);

int prof_expect(int fd, ...);

#endif
