/*
 * stub_http_upload.c
 *
 * Copyright (C) 2017 James Booth <boothj5@gmail.com>
 * Copyright (C) 2020 - 2026 Michael Vetter <jubalh@iodoru.org>
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#ifndef TOOLS_HTTP_UPLOAD_H
#define TOOLS_HTTP_UPLOAD_H

#include <curl/curl.h>
#include <pthread.h>

// forward -> ui/win_types.h
typedef struct prof_win_t ProfWin;

typedef struct http_upload_t
{
    char* filename;
    off_t filesize;
    curl_off_t bytes_sent;
    char* mime_type;
    char* get_url;
    char* put_url;
    ProfWin* window;
    pthread_t worker;
    int cancel;
} HTTPUpload;

void*
http_file_put(void* userdata)
{
    return NULL;
}

char*
file_mime_type(const char* const file_name)
{
    return NULL;
}

off_t
file_size(int filedes)
{
    return 0;
}

void http_upload_cancel_processes() {};
void http_upload_add_upload() {};

#endif
