void returns_false_when_chat_session_does_not_exist(void** state);
void creates_chat_session_on_recipient_activity(void** state);
void replaces_chat_session_on_recipient_activity_with_different_resource(void** state);
void removes_chat_session(void** state);
