void cmd_sub_shows_message_when_not_connected(void** state);
void cmd_sub_shows_usage_when_no_arg(void** state);
