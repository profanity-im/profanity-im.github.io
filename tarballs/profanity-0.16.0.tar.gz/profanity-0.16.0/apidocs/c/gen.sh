rm -rf html && doxygen c-prof.conf
