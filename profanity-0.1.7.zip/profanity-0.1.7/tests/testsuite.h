#ifndef TESTSUITE_H
#define TESTSUITE_H

void register_prof_history_tests(void);
void register_contact_list_tests(void);
void register_util_tests(void);
void register_prof_autocomplete_tests(void);

#endif
