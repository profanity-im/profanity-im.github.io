void send_receipt_request(void **state);
void send_receipt_on_request(void **state);

