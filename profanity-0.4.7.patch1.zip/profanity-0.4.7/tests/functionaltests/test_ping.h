void ping_multiple(void **state);
void ping_responds(void **state);
