#include "xmpp/message.h"

ProfMessage *message_init(void) {
    return NULL;
}

void message_free(ProfMessage *message) {}
