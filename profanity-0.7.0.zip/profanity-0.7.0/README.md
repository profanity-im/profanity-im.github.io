Profanity [![Build Status](https://api.travis-ci.org/profanity-im/profanity.png?branch=master)](https://travis-ci.org/profanity-im/profanity)
=========

Profanity is a console based XMPP client inspired by [Irssi](http://www.irssi.org/),

![alt tag](https://profanity-im.github.io/images/prof-1.png)

See the [User Guide](https://profanity-im.github.io/userguide.html) for information on installing and using Profanity.

Links
-----

Homepage: https://profanity-im.github.io/

Mailing List: https://groups.google.com/forum/#!forum/profanitydev

MUC: profanity@rooms.dismail.de

Plugins repository: https://github.com/profanity-im/profanity-plugins
